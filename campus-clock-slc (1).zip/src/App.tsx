/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo, FormEvent } from "react";
import { 
  Clock, 
  Calendar, 
  Download, 
  Plus, 
  Trash2, 
  Edit3, 
  Info, 
  Sparkles, 
  Sliders, 
  X, 
  MapPin, 
  User, 
  List, 
  Grid, 
  BookOpen, 
  RefreshCw, 
  ArrowRight,
  Smartphone,
  Check,
  AlertCircle
} from "lucide-react";

// Types
interface ScheduleEvent {
  id: string;
  title: string;
  day: "Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday";
  startTime: string; // Format "HH:MM"
  endTime: string;   // Format "HH:MM"
  location: string;
  teacher: string;
  notes?: string;
  color: string;     // Color key for predefined palettes
}

// Fixed weekday sorting helper
const DAYS_ORDER = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"] as const;
type DayName = typeof DAYS_ORDER[number];

// Standard color presets designed with elegant high-contrast styling
const COLOR_PALETTES: { [key: string]: { label: string; bg: string; text: string; border: string; accent: string } } = {
  blue: { label: "Ocean Blue", bg: "bg-blue-50 dark:bg-blue-950/40", text: "text-blue-700 dark:text-blue-300", border: "border-blue-200 dark:border-blue-900/60", accent: "bg-blue-500" },
  indigo: { label: "Electric Indigo", bg: "bg-indigo-50 dark:bg-indigo-950/40", text: "text-indigo-700 dark:text-indigo-300", border: "border-indigo-200 dark:border-indigo-900/60", accent: "bg-indigo-500" },
  emerald: { label: "Bright Emerald", bg: "bg-emerald-50 dark:bg-emerald-950/40", text: "text-emerald-700 dark:text-emerald-300", border: "border-emerald-200 dark:border-emerald-900/60", accent: "bg-emerald-500" },
  violet: { label: "Royal Violet", bg: "bg-violet-50 dark:bg-violet-950/40", text: "text-violet-700 dark:text-violet-300", border: "border-violet-200 dark:border-violet-900/60", accent: "bg-violet-500" },
  rose: { label: "Soft Rose", bg: "bg-rose-50 dark:bg-rose-950/40", text: "text-rose-700 dark:text-rose-300", border: "border-rose-200 dark:border-rose-900/60", accent: "bg-rose-500" },
  amber: { label: "Warm Amber", bg: "bg-amber-50 dark:bg-amber-950/40", text: "text-amber-700 dark:text-amber-300", border: "border-amber-200 dark:border-amber-900/60", accent: "bg-amber-500" },
  teal: { label: "Mint Teal", bg: "bg-teal-50 dark:bg-teal-950/40", text: "text-teal-700 dark:text-teal-300", border: "border-teal-200 dark:border-teal-900/60", accent: "bg-teal-500" },
};

// Default high-fidelity template classes for first load
const DEFAULT_CLASSES: ScheduleEvent[] = [
  {
    id: "class-1",
    title: "Interactive Graphics",
    day: "Monday",
    startTime: "09:00",
    endTime: "10:30",
    location: "Studio 402",
    teacher: "Dr. Evelyn Wright",
    notes: "Review OpenGL matrix transformations.",
    color: "blue"
  },
  {
    id: "class-1-dup",
    title: "Interactive Graphics",
    day: "Wednesday",
    startTime: "09:00",
    endTime: "10:30",
    location: "Studio 402",
    teacher: "Dr. Evelyn Wright",
    notes: "Review OpenGL matrix transformations.",
    color: "blue"
  },
  {
    id: "class-2",
    title: "Artificial Intelligence",
    day: "Monday",
    startTime: "11:00",
    endTime: "12:30",
    location: "Lecture Hall 101",
    teacher: "Prof. Marcus Stone",
    notes: "Midterm project presentation criteria review.",
    color: "indigo"
  },
  {
    id: "class-2-dup",
    title: "Artificial Intelligence",
    day: "Wednesday",
    startTime: "11:00",
    endTime: "12:30",
    location: "Lecture Hall 101",
    teacher: "Prof. Marcus Stone",
    notes: "Midterm project presentation criteria review.",
    color: "indigo"
  },
  {
    id: "class-3",
    title: "Database Engineering",
    day: "Tuesday",
    startTime: "10:00",
    endTime: "11:30",
    location: "Lab Room 304",
    teacher: "Dr. Sarah Jenkins",
    notes: "Bring PostgreSQL lab setup instructions.",
    color: "emerald"
  },
  {
    id: "class-4",
    title: "Human-Computer Interaction",
    day: "Tuesday",
    startTime: "14:00",
    endTime: "15:30",
    location: "Tech Sandbox 215",
    teacher: "Prof. Clara Sterling",
    notes: "Usability testing peer studies.",
    color: "violet"
  },
  {
    id: "class-5",
    title: "Computer Networks & Security",
    day: "Thursday",
    startTime: "10:00",
    endTime: "11:30",
    location: "Lab Room 304",
    teacher: "Dr. Raymond West",
    notes: "Analysis of packet filtering & routing logs.",
    color: "amber"
  },
  {
    id: "class-6",
    title: "Mobile Architecture & App Dev",
    day: "Friday",
    startTime: "09:30",
    endTime: "12:00",
    location: "Mobile Lab 201",
    teacher: "Dr. Alan Dev",
    notes: "Deploying production-ready build setups.",
    color: "rose"
  }
];

export default function App() {
  // Main database sync state
  const [events, setEvents] = useState<ScheduleEvent[]>(() => {
    const saved = localStorage.getItem("campus_clock_events");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error loading events", e);
      }
    }
    return DEFAULT_CLASSES;
  });

  // Save to localStorage whenever updated
  useEffect(() => {
    localStorage.setItem("campus_clock_events", JSON.stringify(events));
  }, [events]);

  // Visual layout state (weekly grid vs clean lists)
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedDayFilter, setSelectedDayFilter] = useState<string>("All");

  // Time traveller & clock logic state
  const [isTimeSimulated, setIsTimeSimulated] = useState<boolean>(false);
  const [simulatedDay, setSimulatedDay] = useState<DayName>("Tuesday");
  const [simulatedTime, setSimulatedTime] = useState<string>("10:15"); // HH:MM
  const [realTime, setRealTime] = useState<Date>(new Date());

  // Keep actual date updated
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Form states
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [formMode, setFormMode] = useState<"add" | "edit">("add");
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  
  const [formTitle, setFormTitle] = useState("");
  const [formDay, setFormDay] = useState<DayName>("Monday");
  const [formStartTime, setFormStartTime] = useState("09:00");
  const [formEndTime, setFormEndTime] = useState("10:30");
  const [formLocation, setFormLocation] = useState("");
  const [formTeacher, setFormTeacher] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formColor, setFormColor] = useState("blue");

  // Download guide step popups
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [icsDownloadSuccess, setIcsDownloadSuccess] = useState<boolean>(false);

  // Helper date parsing
  const minutesSinceMidnight = (timeStr: string): number => {
    const [hours, minutes] = timeStr.split(":").map(Number);
    return hours * 60 + minutes;
  };

  // Resolve CURRENT time variables (either real-time or user-simulated)
  const resolvedState = useMemo(() => {
    let dayName: DayName;
    let timeStr: string;
    let secondsStr = "00";

    if (isTimeSimulated) {
      dayName = simulatedDay;
      timeStr = simulatedTime;
    } else {
      const weekdays: DayName[] = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      dayName = weekdays[realTime.getDay()];
      
      const hh = String(realTime.getHours()).padStart(2, "0");
      const mm = String(realTime.getMinutes()).padStart(2, "0");
      const ss = String(realTime.getSeconds()).padStart(2, "0");
      timeStr = `${hh}:${mm}`;
      secondsStr = ss;
    }

    const currentMinutes = minutesSinceMidnight(timeStr);

    return {
      dayName,
      timeStr,
      secondsStr,
      currentMinutes
    };
  }, [isTimeSimulated, simulatedDay, simulatedTime, realTime]);

  // Dynamic status evaluation: is there a class right now? What class starts next?
  const liveStatus = useMemo(() => {
    const { dayName, currentMinutes } = resolvedState;
    const dayClasses = events.filter((e) => e.day === dayName);

    // 1. Find live class
    const activeClass = dayClasses.find((c) => {
      const start = minutesSinceMidnight(c.startTime);
      const end = minutesSinceMidnight(c.endTime);
      return currentMinutes >= start && currentMinutes < end;
    });

    if (activeClass) {
      const endMinutes = minutesSinceMidnight(activeClass.endTime);
      const remainingMinutes = endMinutes - currentMinutes;
      return {
        type: "active" as const,
        currentClass: activeClass,
        countdownText: `${remainingMinutes} min${remainingMinutes !== 1 ? "s" : ""} left`,
        percentageDone: Math.round(((currentMinutes - minutesSinceMidnight(activeClass.startTime)) / (endMinutes - minutesSinceMidnight(activeClass.startTime))) * 100)
      };
    }

    // 2. Find next upcoming class today
    const upcomingToday = dayClasses
      .filter((c) => minutesSinceMidnight(c.startTime) > currentMinutes)
      .sort((a, b) => minutesSinceMidnight(a.startTime) - minutesSinceMidnight(b.startTime));

    if (upcomingToday.length > 0) {
      const nextClass = upcomingToday[0];
      const startMinutes = minutesSinceMidnight(nextClass.startTime);
      const waitMinutes = startMinutes - currentMinutes;
      const hh = Math.floor(waitMinutes / 60);
      const mm = waitMinutes % 60;
      const timeRemaining = hh > 0 ? `${hh}h ${mm}m` : `${mm}m`;

      return {
        type: "upcoming" as const,
        nextClass,
        countdownText: `Starts in ${timeRemaining}`,
        relativeSubtitle: `Upcoming Today at ${nextClass.startTime} (${nextClass.location})`
      };
    }

    // 3. Look ahead for future days to find the next nearest class
    const todayIndex = DAYS_ORDER.indexOf(dayName);
    let nextClassFound: ScheduleEvent | null = null;
    let daysToWaitStr = "";

    for (let i = 1; i <= 7; i++) {
      const checkDayIndex = (todayIndex + i) % 7;
      const checkDay = DAYS_ORDER[checkDayIndex];
      const checkDayClasses = events
        .filter((e) => e.day === checkDay)
        .sort((a, b) => minutesSinceMidnight(a.startTime) - minutesSinceMidnight(b.startTime));

      if (checkDayClasses.length > 0) {
        nextClassFound = checkDayClasses[0];
        daysToWaitStr = i === 1 ? "Tomorrow" : `In ${i} days`;
        break;
      }
    }

    if (nextClassFound) {
      return {
        type: "distant" as const,
        nextClass: nextClassFound,
        countdownText: `${daysToWaitStr} at ${nextClassFound.startTime}`,
        relativeSubtitle: `${nextClassFound.day} • ${nextClassFound.location}`
      };
    }

    return {
      type: "empty" as const,
      countdownText: "No classes scheduled"
    };
  }, [events, resolvedState]);

  // Export timetable events to an standard Universal ICS (iCalendar) payload
  const handleExportICS = () => {
    if (events.length === 0) {
      alert("No classes to export. Create or load template classes first.");
      return;
    }

    let icsContent = [
      "BEGIN:VCALENDAR",
      "VERSION:2.0",
      "PRODID:-//Campus Clock SLC+//Timetable System//EN",
      "CALSCALE:GREGORIAN",
      "METHOD:PUBLISH"
    ];

    // Array matching standard day offsets (Monday is base index 0)
    const dayOffsets: { [key: string]: string } = {
      Monday: "MO",
      Tuesday: "TU",
      Wednesday: "WE",
      Thursday: "TH",
      Friday: "FR",
      Saturday: "SA",
      Sunday: "SU"
    };

    // Calculate sequential base dates from our target week starting on Monday, June 8, 2026.
    // This allows the exported event to recurrently sync to correct weekdays immediately!
    const dayBaseDates: { [key: string]: string } = {
      Monday: "20260608",
      Tuesday: "20260609",
      Wednesday: "20260610",
      Thursday: "20260611",
      Friday: "20260612",
      Saturday: "20260613",
      Sunday: "20260614"
    };

    events.forEach((evt) => {
      const baseDate = dayBaseDates[evt.day] || "20260608";
      const startT = evt.startTime.replace(":", "") + "00";
      const endT = evt.endTime.replace(":", "") + "00";
      const dayCode = dayOffsets[evt.day] || "MO";

      icsContent.push("BEGIN:VEVENT");
      icsContent.push(`UID:campus-clock-slc-${evt.id}@slcplus.edu`);
      icsContent.push(`DTSTAMP:20260609T054000Z`);
      icsContent.push(`DTSTART;TZID=UTC:${baseDate}T${startT}`);
      icsContent.push(`DTEND;TZID=UTC:${baseDate}T${endT}`);
      // Standard RRULE representing recurrence repeats every week for a standard semester length
      icsContent.push(`RRULE:FREQ=WEEKLY;BYDAY=${dayCode};UNTIL=20261231T235959Z`);
      icsContent.push(`SUMMARY:${evt.title.replace(/[,;]/g, "\\$&")}`);
      icsContent.push(`LOCATION:${evt.location.replace(/[,;]/g, "\\$&")}`);
      icsContent.push(`DESCRIPTION:Instructor Name: ${evt.teacher.replace(/[,;]/g, "\\$&")}\\nNotes: ${(evt.notes || "").replace(/[,;]/g, "\\$&")}`);
      icsContent.push("END:VEVENT");
    });

    icsContent.push("END:VCALENDAR");

    const fullBlobString = icsContent.join("\n");
    const blob = new Blob([fullBlobString], { type: "text/calendar;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "CampusClock_SLC_Timetable.ics";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setIcsDownloadSuccess(true);
    setTimeout(() => setIcsDownloadSuccess(false), 8000);
  };

  // Reset/reseed template schedule
  const handleReseedTemplates = () => {
    if (window.confirm("Reseed template? This will replace your current edits with our design masterplan.")) {
      setEvents(DEFAULT_CLASSES);
    }
  };

  // Event handlers
  const openAddForm = () => {
    setFormMode("add");
    setEditingEventId(null);
    setFormTitle("");
    setFormDay("Monday");
    setFormStartTime("09:00");
    setFormEndTime("10:30");
    setFormLocation("");
    setFormTeacher("");
    setFormNotes("");
    setFormColor("indigo");
    setIsFormOpen(true);
  };

  const openEditForm = (evt: ScheduleEvent) => {
    setFormMode("edit");
    setEditingEventId(evt.id);
    setFormTitle(evt.title);
    setFormDay(evt.day);
    setFormStartTime(evt.startTime);
    setFormEndTime(evt.endTime);
    setFormLocation(evt.location);
    setFormTeacher(evt.teacher);
    setFormNotes(evt.notes || "");
    setFormColor(evt.color);
    setIsFormOpen(true);
  };

  const handleSaveEvent = (e: FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formStartTime || !formEndTime || !formLocation.trim()) {
      alert("Please complete all required fields (Class Title, Start Time, End Time & Location).");
      return;
    }

    if (minutesSinceMidnight(formStartTime) >= minutesSinceMidnight(formEndTime)) {
      alert("Class start time must be strictly before end time.");
      return;
    }

    if (formMode === "add") {
      const newEvent: ScheduleEvent = {
        id: `custom-class-${Date.now()}`,
        title: formTitle,
        day: formDay,
        startTime: formStartTime,
        endTime: formEndTime,
        location: formLocation,
        teacher: formTeacher,
        notes: formNotes,
        color: formColor
      };
      setEvents((prev) => [...prev, newEvent]);
    } else {
      setEvents((prev) =>
        prev.map((evt) =>
          evt.id === editingEventId
            ? {
                ...evt,
                title: formTitle,
                day: formDay,
                startTime: formStartTime,
                endTime: formEndTime,
                location: formLocation,
                teacher: formTeacher,
                notes: formNotes,
                color: formColor
              }
            : evt
        )
      );
    }
    setIsFormOpen(false);
  };

  const handleDeleteEvent = (id: string) => {
    if (window.confirm("Are you sure you want to delete this class from your timetable?")) {
      setEvents((prev) => prev.filter((e) => e.id !== id));
    }
  };

  // Group events by day to feed the dashboard render logic easily
  const groupedEventsByDay = useMemo(() => {
    const map: { [key in DayName]: ScheduleEvent[] } = {
      Monday: [],
      Tuesday: [],
      Wednesday: [],
      Thursday: [],
      Friday: [],
      Saturday: [],
      Sunday: []
    };
    events.forEach((evt) => {
      if (map[evt.day]) {
        map[evt.day].push(evt);
      }
    });

    // Sort classes in each day by start hour
    Object.keys(map).forEach((day) => {
      map[day as DayName].sort((a, b) => minutesSinceMidnight(a.startTime) - minutesSinceMidnight(b.startTime));
    });

    return map;
  }, [events]);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 transition-colors duration-300 flex flex-col antialiased">
      
      {/* HEADER SECTION */}
      <header id="header_section" className="border-b border-slate-200 dark:border-slate-800/80 bg-white/75 dark:bg-slate-900/75 backdrop-blur-md sticky top-0 z-40 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-indigo-600 flex items-center justify-center text-white font-black tracking-tight shadow-md shadow-emerald-500/10">
              SLC+
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-1.5">
                Campus Clock SLC+
                <span className="text-xs bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-semibold px-2 py-0.5 rounded-full">
                  iCal Ready
                </span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">Timetable Planner & Calendar Sync</p>
            </div>
          </div>

          {/* Core App Information and Global CTAs */}
          <div className="flex items-center space-x-2">
            <button
              id="help_btn"
              onClick={() => setIsHelpOpen(!isHelpOpen)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center gap-1.5"
            >
              <Smartphone className="w-3.5 h-3.5" />
              How to Import on Mobile?
            </button>
            <button
              id="export_ics_btn"
              onClick={handleExportICS}
              className="px-3.5 py-1.5 rounded-lg text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600 transition flex items-center gap-1.5 shadow-sm shadow-indigo-500/10"
            >
              <Download className="w-3.5 h-3.5" />
              Download Calendar
            </button>
            <button
              id="add_class_btn"
              onClick={openAddForm}
              className="h-8 w-8 rounded-lg bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center hover:bg-emerald-700 dark:hover:bg-emerald-600 transition"
              title="Add New Lesson"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-grow w-full flex flex-col gap-6">

        {/* HELP POPUP GUIDE PANEL */}
        {isHelpOpen && (
          <div id="help_modal_panel" className="bg-gradient-to-r from-indigo-500/5 to-emerald-500/5 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl relative transition duration-200 animate-fadeIn">
            <button 
              onClick={() => setIsHelpOpen(false)}
              className="absolute top-4 right-4 p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4 text-slate-500" />
            </button>
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3">
              <Smartphone className="w-5 h-5 text-indigo-500" />
              How to Download and Sync with iOS or Android Devices
            </h3>
            
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4 max-w-4xl">
              Our file exporter creates safe, structured <strong className="text-emerald-600 dark:text-emerald-400">universal iCalendar (.ics) format files</strong>. This file type runs natively on all major operating systems. It allows all your school courses to import simultaneously, with precise recurring weekly patterns.
            </p>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-150 dark:border-slate-800/80">
                <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block mb-1">Method A: Apple iOS Device (iPhone/iPad)</span>
                <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-2 list-decimal list-inside">
                  <li>Click <span className="font-semibold text-slate-800 dark:text-slate-200">"Download Calendar"</span> above to save the calendar file.</li>
                  <li>Airdrop or Email the downloaded <code className="text-indigo-600 dark:text-indigo-300">.ics</code> file to your mobile, OR upload it to iCloud Drive.</li>
                  <li>Tap the file on your Apple iOS device. iOS will open a prompt listing all classes automatically.</li>
                  <li>Tap <span className="font-semibold text-slate-800 dark:text-slate-200">"Add All"</span> and assign them to your preferred target device calendar color channel!</li>
                </ul>
              </div>

              <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-150 dark:border-slate-800/80">
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider block mb-1">Method B: Chrome Android / Google Calendar</span>
                <ul className="text-xs text-slate-600 dark:text-slate-400 space-y-2 list-decimal list-inside">
                  <li>Click <span className="font-semibold text-slate-800 dark:text-slate-200">"Download Calendar"</span> to retrieve the global ICS scheduler bundle.</li>
                  <li>Visit your computer browser on <a href="https://calendar.google.com" target="_blank" rel="noreferrer" className="text-indigo-600 dark:text-indigo-400 underline font-semibold">Google Calendar</a>.</li>
                  <li>Click the **Settings Icon ⚙** &rarr; Select <strong className="text-slate-800 dark:text-slate-200">"Import & export"</strong> in the sidebar.</li>
                  <li>Drop the downloaded file in the importer slot and choose which Google Calendar sub-group to inject the schedules into!</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-3 text-xs text-slate-400 dark:text-slate-500 italic flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-500" />
              Note: All event notifications, room numbers, teacher labels, and notes will sync right onto your device's widgets!
            </div>
          </div>
        )}

        {/* FEEDBACK NOTICE UPON ICS EXPORT */}
        {icsDownloadSuccess && (
          <div className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/60 p-4 rounded-xl flex items-start gap-3 animate-slideDown">
            <Check className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-bold">Successfully generated "CampusClock_SLC_Timetable.ics"!</p>
              <p className="text-xs opacity-90 mt-1">
                Import this file to Apple Calendar (iOS) or Google Calendar (Android) so your mobile device displays your weekly classes and alerts automatically! Refer to the import instructions above for guidance.
              </p>
            </div>
          </div>
        )}

        {/* BENTO GRID: LIVE CAMPUS CLOCK & TIME CONTROL PANEL */}
        <div className="grid lg:grid-cols-3 gap-6">
          
          {/* COLUMN 1: LIVE CAMPUS CLOCK & STATE STATUS DISPLAY */}
          <div className="lg:col-span-2 bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-2xl p-6 shadow-lg relative overflow-hidden flex flex-col justify-between min-h-[220px]">
            {/* Visual background overlay rings */}
            <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-2xl" />
            <div className="absolute left-1/3 top-0 -translate-y-4 w-40 h-40 bg-emerald-500/5 rounded-full blur-xl" />

            <div className="flex justify-between items-start z-10">
              <div>
                <span className="text-xs font-bold text-indigo-300 uppercase tracking-wider block mb-1">
                  {isTimeSimulated ? "⚠️ Simulation Mode Active" : "⏱️ LIVE Campus Clock"}
                </span>
                <span className="text-2xl font-black tracking-tight flex items-baseline gap-1">
                  {resolvedState.dayName}
                  <span className="text-sm font-medium text-slate-300 ml-2">
                    {isTimeSimulated ? "Simulated Day" : `June 09, 2026`}
                  </span>
                </span>
              </div>
              <div className="flex items-center space-x-1 bg-white/10 px-2.5 py-1 rounded-full text-xs font-medium backdrop-blur-sm">
                <Clock className="w-3 h-3 text-emerald-400" />
                <span className="text-slate-200">
                  {isTimeSimulated ? "TRAVELLER ON" : "UTC CLOCK"}
                </span>
              </div>
            </div>

            {/* GIANT TIME DIGITS */}
            <div className="my-5 z-10">
              <div className="flex items-baseline font-mono text-5xl sm:text-6xl font-extrabold tracking-tight">
                <span>{resolvedState.timeStr}</span>
                <span className="text-emerald-400 text-3xl sm:text-4xl font-normal ml-1">:{resolvedState.secondsStr}</span>
              </div>
            </div>

            {/* LIVE DYNAMIC LESSON ALERT CARD */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-4.5 z-10 backdrop-blur-sm">
              {liveStatus.type === "active" && liveStatus.currentClass && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-amber-400 tracking-wider flex items-center gap-1.5 uppercase">
                      <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                      Class In Progress
                    </span>
                    <span className="text-xs bg-slate-800 border border-slate-700 px-2 py-0.5 rounded text-indigo-200">
                      Duration: {liveStatus.currentClass.startTime} - {liveStatus.currentClass.endTime}
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">{liveStatus.currentClass.title}</h4>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-300 mt-1">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-indigo-400" />
                      {liveStatus.currentClass.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3 text-emerald-400" />
                      {liveStatus.currentClass.teacher}
                    </span>
                    <span className="font-bold text-indigo-300 ml-auto">{liveStatus.countdownText}</span>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="w-full bg-slate-800 h-1.5 rounded-full mt-3 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-emerald-400 to-indigo-500 h-1.5 rounded-full transition-all duration-1000"
                      style={{ width: `${liveStatus.percentageDone}%` }}
                    />
                  </div>
                </div>
              )}

              {liveStatus.type === "upcoming" && liveStatus.nextClass && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-emerald-400 tracking-wider uppercase">
                      Up Next Today
                    </span>
                    <span className="text-xs text-indigo-200 font-bold bg-indigo-900/60 px-2.5 py-0.5 rounded-full">
                      {liveStatus.countdownText}
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">{liveStatus.nextClass.title}</h4>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-300 mt-1">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {liveStatus.nextClass.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-400" />
                      {liveStatus.nextClass.teacher}
                    </span>
                  </div>
                </div>
              )}

              {liveStatus.type === "distant" && liveStatus.nextClass && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-indigo-300 tracking-wider uppercase">
                      Next Scheduled Class
                    </span>
                    <span className="text-xs text-indigo-200 font-bold bg-indigo-950/60 px-2.5 py-0.5 rounded-full">
                      {liveStatus.countdownText}
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">{liveStatus.nextClass.title}</h4>
                  <p className="text-xs text-slate-300 mt-1">
                    {liveStatus.relativeSubtitle} with {liveStatus.nextClass.teacher}
                  </p>
                </div>
              )}

              {liveStatus.type === "empty" && (
                <div className="text-center py-2">
                  <BookOpen className="w-5 h-5 text-indigo-400 mx-auto opacity-70 mb-1" />
                  <p className="text-sm font-semibold text-slate-300">{liveStatus.countdownText}</p>
                  <p className="text-xs text-slate-400 mt-0.5">Please populate classes or change the target hours of study.</p>
                </div>
              )}
            </div>
          </div>

          {/* COLUMN 2: TIME SLIDER & SIMULATION TRAVEL ENGINE */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-md flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-slate-950 dark:text-white flex items-center gap-2 text-sm leading-none">
                  <Sliders className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  Time Travel Engine
                </h3>
                <div className="relative inline-block w-10 mr-2 align-middle select-none transition duration-200 ease-in">
                  <input
                    type="checkbox"
                    name="toggle"
                    id="sim_toggle"
                    checked={isTimeSimulated}
                    onChange={(e) => setIsTimeSimulated(e.target.checked)}
                    className="sr-only"
                  />
                  <label
                    htmlFor="sim_toggle"
                    className={`block overflow-hidden h-6 rounded-full cursor-pointer transition ${
                      isTimeSimulated ? "bg-emerald-500" : "bg-slate-300 dark:bg-slate-700"
                    }`}
                  >
                    <span
                      className={`block h-4 w-4 bg-white rounded-full m-1 transform transition duration-200 ${
                        isTimeSimulated ? "translate-x-4" : "translate-x-0"
                      }`}
                    />
                  </label>
                </div>
              </div>

              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4 h-[32px] overflow-hidden leading-snug">
                Simulate different hours and school weekdays to test how the countdown clock transitions and updates dynamically.
              </p>

              <div className="space-y-4.5 mt-2">
                {/* Day selector */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-widest mb-1.5">
                    Select Test Weekday
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {DAYS_ORDER.map((day) => (
                      <button
                        key={day}
                        disabled={!isTimeSimulated}
                        onClick={() => setSimulatedDay(day)}
                        className={`py-1 text-2xs font-bold rounded transition ${
                          !isTimeSimulated 
                            ? "bg-slate-100 dark:bg-slate-800/40 text-slate-300 dark:text-slate-600 cursor-not-allowed"
                            : simulatedDay === day
                            ? "bg-indigo-600 text-white shadow-sm"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700"
                        }`}
                      >
                        {day.substring(0, 3)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Time picker slider */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[11px] font-bold text-slate-400 dark:text-slate-400 uppercase tracking-widest">
                      Select Test Clock Time
                    </label>
                    <span className={`text-xs font-mono font-bold ${isTimeSimulated ? "text-indigo-600 dark:text-indigo-400" : "text-slate-300 dark:text-slate-600"}`}>
                      {simulatedTime}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="480" // 08:00
                    max="1200" // 20:00
                    step="10"
                    disabled={!isTimeSimulated}
                    value={minutesSinceMidnight(simulatedTime)}
                    onChange={(e) => {
                      const totalMin = Number(e.target.value);
                      const h = String(Math.floor(totalMin / 60)).padStart(2, "0");
                      const m = String(totalMin % 60).padStart(2, "0");
                      setSimulatedTime(`${h}:${m}`);
                    }}
                    className={`w-full h-2 rounded-lg appearance-none cursor-pointer ${
                      isTimeSimulated ? "accent-indigo-600 bg-indigo-100 dark:bg-indigo-950" : "bg-slate-200 dark:bg-slate-800 cursor-not-allowed"
                    }`}
                  />
                  <div className="flex justify-between text-[10px] text-slate-400 px-1 mt-0.5">
                    <span>08:00 AM</span>
                    <span>02:00 PM</span>
                    <span>08:00 PM</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick action buttons to load presets */}
            <div className="border-t border-slate-150 dark:border-slate-800/80 pt-3 mt-4 flex items-center justify-between text-2xs text-slate-400">
              <span>Database seeders:</span>
              <button
                id="reseed_btn"
                onClick={handleReseedTemplates}
                className="text-indigo-600 dark:text-indigo-400 hover:underline font-bold flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                Reset default classes
              </button>
            </div>
          </div>
        </div>

        {/* TIMETABLE CONTENT HEADER & VIEWPANEL FILTERS */}
        <div className="border-t border-slate-200 dark:border-slate-800/80 pt-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
            <div>
              <h2 className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-500" />
                Your Weekly Academic Schedule
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Double-click or tap a course card to edit, delete, or review active notes.
              </p>
            </div>

            {/* Filter controls */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400">View Day:</span>
              <select
                id="day_filter_dropdown"
                value={selectedDayFilter}
                onChange={(e) => setSelectedDayFilter(e.target.value)}
                className="bg-white dark:bg-slate-900 border border-slate-250 dark:border-slate-800 text-xs rounded-lg px-2.5 py-1.5 font-semibold"
              >
                <option value="All">All Weekdays (Grid)</option>
                {DAYS_ORDER.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </select>

              {/* View toggle */}
              <div className="flex border border-slate-250 dark:border-slate-800 rounded-lg overflow-hidden bg-white dark:bg-slate-900">
                <button
                  id="view_grid_btn"
                  onClick={() => setViewMode("grid")}
                  className={`p-1.5 ${viewMode === "grid" ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-600"}`}
                  title="Weekly Grid View"
                >
                  <Grid className="w-4 h-4" />
                </button>
                <button
                  id="view_list_btn"
                  onClick={() => setViewMode("list")}
                  className={`p-1.5 ${viewMode === "list" ? "bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400" : "text-slate-400 hover:text-slate-600"}`}
                  title="List Agenda View"
                >
                  <List className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* EVENTS CONTENT CONTAINER */}

          {events.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 p-12 text-center">
              <BookOpen className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Your study schedule is empty</h3>
              <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto mt-1 mb-6">
                Build your core campus class calendar now or seed default curriculum templates in one tap.
              </p>
              <div className="flex justify-center gap-3">
                <button
                  onClick={handleReseedTemplates}
                  className="px-4 py-2 text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                >
                  Load Template Classes
                </button>
                <button
                  onClick={openAddForm}
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition"
                >
                  Add Custom Class
                </button>
              </div>
            </div>
          ) : viewMode === "grid" && selectedDayFilter === "All" ? (
            /* DESKTOP WEEKLY GRID */
            <div className="hidden md:grid md:grid-cols-7 gap-3 min-h-[420px]">
              {DAYS_ORDER.map((day) => {
                const dayClasses = groupedEventsByDay[day] || [];
                const isCurrentActiveDay = resolvedState.dayName === day;

                return (
                  <div 
                    key={day} 
                    className={`rounded-xl p-3 flex flex-col gap-2.5 transition ${
                      isCurrentActiveDay 
                        ? "bg-slate-150/60 dark:bg-slate-900/60 ring-2 ring-indigo-500/30" 
                        : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/70"
                    }`}
                  >
                    {/* Header */}
                    <div className="border-b border-slate-150 dark:border-slate-800 pb-1.5 flex items-center justify-between">
                      <span className={`text-xs font-bold uppercase tracking-wider ${
                        isCurrentActiveDay ? "text-indigo-600 dark:text-indigo-400" : "text-slate-500 dark:text-slate-400"
                      }`}>
                        {day.substring(0, 3)}
                      </span>
                      {isCurrentActiveDay && (
                        <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" title="Today" />
                      )}
                    </div>

                    {/* Classes inside the day COLUMN */}
                    <div className="flex-1 flex flex-col gap-2">
                      {dayClasses.map((item) => {
                        const palette = COLOR_PALETTES[item.color] || COLOR_PALETTES.blue;
                        // Check if this class is currently live
                        const isLiveNow = resolvedState.dayName === day && (() => {
                          const nowMin = resolvedState.currentMinutes;
                          return nowMin >= minutesSinceMidnight(item.startTime) && nowMin < minutesSinceMidnight(item.endTime);
                        })();

                        return (
                          <div
                            key={item.id}
                            className={`p-3 rounded-lg border text-left flex flex-col justify-between transition-all group relative duration-200 cursor-pointer ${palette.bg} ${palette.border} ${
                              isLiveNow ? "ring-2 ring-amber-400 scale-[1.02] shadow-sm shadow-amber-400/10" : "hover:border-slate-350 dark:hover:border-slate-700 hover:scale-[1.01]"
                            }`}
                            onClick={() => openEditForm(item)}
                          >
                            <div>
                              <div className="flex items-center justify-between gap-1 mb-1">
                                <span className={`text-[10px] font-bold text-slate-400 dark:text-slate-500 group-hover:text-slate-600 dark:group-hover:text-slate-300 transition`}>
                                  {item.startTime} - {item.endTime}
                                </span>
                                {isLiveNow && (
                                  <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.5 rounded uppercase tracking-wider animate-pulse flex items-center gap-0.5">
                                    LIVE
                                  </span>
                                )}
                              </div>
                              <h4 className={`text-xs font-extrabold ${palette.text} line-clamp-2`}>
                                {item.title}
                              </h4>
                              <div className="flex items-center gap-1 mt-1.5 text-[10px] text-slate-500 dark:text-slate-400">
                                <MapPin className="w-2.5 h-2.5 shrink-0 opacity-70" />
                                <span className="truncate">{item.location}</span>
                              </div>
                            </div>

                            <div className="mt-2 pt-1 border-t border-slate-200/50 dark:border-slate-800/40 flex items-center justify-between text-[10px] text-slate-400 dark:text-slate-500">
                              <span className="truncate max-w-[80%]">{item.teacher.split(" ").slice(-1)[0] || item.teacher}</span>
                              <div className="opacity-0 group-hover:opacity-100 transition duration-150 flex items-center gap-1.5">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteEvent(item.id);
                                  }}
                                  className="text-rose-500 hover:text-rose-700 p-0.5"
                                  title="Delete Course"
                                >
                                  <Trash2 className="w-2.5 h-2.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {dayClasses.length === 0 && (
                        <div className="flex-1 flex items-center justify-center border border-dashed border-slate-200 dark:border-slate-800/60 rounded-xl py-6 min-h-[80px]">
                          <span className="text-3xs text-slate-400 uppercase tracking-widest font-mono text-center px-1">Free Day</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* AGENDA LIST VIEW OR SINGLE DAY FILTER (Perfect for mobile screens as well) */
            <div className="space-y-4 max-w-4xl mx-auto">
              {DAYS_ORDER.filter(day => selectedDayFilter === "All" || selectedDayFilter === day).map((day) => {
                const dayClasses = groupedEventsByDay[day] || [];
                const isCurrentActiveDay = resolvedState.dayName === day;

                if (selectedDayFilter === "All" && dayClasses.length === 0) return null; // Hide empty days to make agenda crisp

                return (
                  <div key={day} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                      <h3 className="font-extrabold text-slate-950 dark:text-white flex items-center gap-2">
                        <span className={`h-2.5 w-2.5 rounded-full ${isCurrentActiveDay ? "bg-indigo-500 animate-pulse" : "bg-slate-350 dark:bg-slate-700"}`} />
                        {day}
                      </h3>
                      <span className="text-xs text-slate-400">
                        {dayClasses.length} class{dayClasses.length !== 1 ? "es" : ""} scheduled
                      </span>
                    </div>

                    <div className="space-y-3">
                      {dayClasses.map((item) => {
                        const palette = COLOR_PALETTES[item.color] || COLOR_PALETTES.blue;
                        const isLiveNow = resolvedState.dayName === day && (() => {
                          const nowMin = resolvedState.currentMinutes;
                          return nowMin >= minutesSinceMidnight(item.startTime) && nowMin < minutesSinceMidnight(item.endTime);
                        })();

                        return (
                          <div
                            key={item.id}
                            className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition cursor-pointer ${palette.bg} ${palette.border} hover:scale-[1.005] relative overflow-hidden`}
                            onClick={() => openEditForm(item)}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center gap-4 flex-1">
                              {/* Duration / Color stamp */}
                              <div className="sm:w-32 flex-shrink-0">
                                <span className={`text-xs font-mono font-bold block ${isLiveNow ? "text-amber-500" : "text-slate-500"}`}>
                                  {item.startTime} - {item.endTime}
                                </span>
                                {isLiveNow && (
                                  <span className="inline-block mt-1 text-[9px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.5 rounded uppercase tracking-wider animate-pulse leading-none">
                                    LIVE IN CLASS
                                  </span>
                                )}
                              </div>

                              <div>
                                <h4 className={`text-base font-bold text-slate-900 dark:text-white`}>
                                  {item.title}
                                </h4>
                                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
                                  <span className="flex items-center gap-1 font-semibold">
                                    <MapPin className="w-3.5 h-3.5 opacity-70" />
                                    {item.location}
                                  </span>
                                  <span className="flex items-center gap-1">
                                    <User className="w-3.5 h-3.5 opacity-70" />
                                    Class Instructor: {item.teacher}
                                  </span>
                                </div>
                                {item.notes && (
                                  <p className="text-xs text-slate-400 dark:text-slate-500 mt-2 bg-slate-100/50 dark:bg-slate-950/40 p-2 rounded-lg border border-slate-200/40 dark:border-slate-800/40 italic">
                                    "{item.notes}"
                                  </p>
                                )}
                              </div>
                            </div>

                            {/* Actions */}
                            <div className="flex items-center gap-2 self-end sm:self-center border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-200/50">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openEditForm(item);
                                }}
                                className="p-1 px-2 text-2xs font-semibold bg-white dark:bg-slate-850 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700/60 rounded text-slate-600 dark:text-slate-300 flex items-center gap-1"
                              >
                                <Edit3 className="w-3 h-3" />
                                Edit
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteEvent(item.id);
                                }}
                                className="p-1.5 text-rose-500 hover:text-white hover:bg-rose-600/90 rounded border border-rose-200/30 transition"
                                title="Delete Class"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        );
                      })}

                      {dayClasses.length === 0 && (
                        <div className="text-center py-8 text-slate-400 dark:text-slate-500 border border-dashed border-slate-200 dark:border-slate-800 rounded-xl">
                          <AlertCircle className="w-6 h-6 mx-auto opacity-40 mb-1" />
                          <p className="text-xs">No courses on this day.</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Clean view of grid on mobile device alerts */}
          <div className="block md:hidden text-center mt-3 text-xs text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20 py-2.5 rounded-lg border border-indigo-150/40">
            📱 Swipe and use dropdown menus to filter daily schedules comfortably!
          </div>
        </div>
      </main>

      {/* FOOTER PERSIST_INFO OUTLINE */}
      <footer id="footer_section" className="border-t border-slate-200 dark:border-slate-800/80 bg-white/50 dark:bg-slate-900/40 text-slate-550 dark:text-slate-400 py-6 text-center text-xs mt-12 transition">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <p>&copy; 2226 Campus Clock SLC+ Timetable Interface for Android & iOS Applets.</p>
          <div className="flex items-center space-x-4">
            <span className="flex items-center gap-1 text-2xs bg-slate-100 dark:bg-slate-800/75 px-2 py-1 rounded">
              <Sparkles className="w-3 h-3 text-emerald-500" /> Web App Environment Active
            </span>
            <span className="text-slate-400">|</span>
            <button 
              onClick={() => {
                setEvents(DEFAULT_CLASSES);
              }}
              className="hover:underline hover:text-slate-900 dark:hover:text-white"
            >
              Reset Core Seed Data
            </button>
          </div>
        </div>
      </footer>

      {/* POPUP MODAL COMPONENT (ADD & EDIT CLASS FORM) */}
      {isFormOpen && (
        <div id="form_modal" className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-150 dark:border-slate-800 w-full max-w-lg overflow-hidden shadow-xl animate-scaleUp">
            
            {/* Header */}
            <div className="bg-slate-100 dark:bg-slate-850 px-6 py-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-indigo-505" />
                {formMode === "add" ? "Schedule New Class" : "Edit Course Settings"}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition"
              >
                <X className="w-4 h-4 text-slate-500" />
              </button>
            </div>

            {/* Input Form Fields */}
            <form onSubmit={handleSaveEvent} className="p-6 space-y-4">
              
              <div>
                <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Class Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Computer Science II"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Weekday <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formDay}
                    onChange={(e) => setFormDay(e.target.value as DayName)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
                  >
                    {DAYS_ORDER.map((d) => (
                      <option key={d} value={d}>
                        {d}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Theme Color
                  </label>
                  <div className="flex gap-1.5 py-2">
                    {Object.keys(COLOR_PALETTES).map((colName) => {
                      const pal = COLOR_PALETTES[colName];
                      return (
                        <button
                          key={colName}
                          type="button"
                          onClick={() => setFormColor(colName)}
                          className={`w-6 h-6 rounded-full ${pal.accent} transition flex items-center justify-center`}
                          title={pal.label}
                        >
                          {formColor === colName && (
                            <Check className="w-3.5 h-3.5 text-white stroke-[3.5]" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Start Time <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={formStartTime}
                    onChange={(e) => setFormStartTime(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    End Time <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={formEndTime}
                    onChange={(e) => setFormEndTime(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Room / Location <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Auditiorium B"
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                    Professor Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Dr. Newton"
                    value={formTeacher}
                    onChange={(e) => setFormTeacher(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-2xs font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Additional Notes
                </label>
                <textarea
                  placeholder="Optional assignment deadlines or link references"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-855 rounded-lg px-3 py-2 text-sm text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-150 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-350 hover:bg-slate-200 rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition"
                >
                  Save Class
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
