import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../basic_feture/ProfileScreen.dart';
import 'package:campus_clock_slc/Student/StudentAttendanceAnalyticsScreen.dart'; // adjust path

class StudentQRCodeScreen extends StatefulWidget {
  const StudentQRCodeScreen({super.key});

  @override
  State<StudentQRCodeScreen> createState() => _StudentQRCodeScreenState();
}

class _StudentQRCodeScreenState extends State<StudentQRCodeScreen> {
  String _qrData = '';
  bool _isLoading = true;
  String? _studentName;
  String? _rollNumber;

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  Future<void> _loadStudentData() async {
    final prefs = await SharedPreferences.getInstance();
    final name = prefs.getString('student_name') ?? prefs.getString('user_name');
    final roll = prefs.getString('roll_number');
    final course = prefs.getString('selected_course');

    if (name == null || name.isEmpty || roll == null || roll.isEmpty || course == null || course.isEmpty) {
      if (mounted) {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ProfileScreen()),
        );
        if (result == true) {
          await _loadStudentData();
        } else {
          if (mounted) Navigator.pop(context);
        }
      }
      return;
    }

    _studentName = name;
    _rollNumber = roll;

    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final payload = {
      'name': name,
      'rollNumber': roll,
      'course': course,
      'date': today,
    };

    setState(() {
      _qrData = jsonEncode(payload);
      _isLoading = false;
    });
  }

  Future<void> _simulateAttendanceScan() async {
    setState(() => _isLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final course = prefs.getString('selected_course') ?? 'Computer Science';
      final roll = prefs.getString('roll_number') ?? _rollNumber;
      final name = prefs.getString('student_name') ?? prefs.getString('user_name') ?? _studentName ?? 'Test Student';
      final userId = prefs.getString('user_id') ?? FirebaseAuth.instance.currentUser?.uid;

      if (userId == null || roll == null || roll.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error: Student profile details incomplete'), backgroundColor: Colors.red),
        );
        setState(() => _isLoading = false);
        return;
      }

      final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
      final attendanceId = '${userId}_$today';

      // 1. Mark in FireStore
      await FirebaseFirestore.instance.collection('attendance').doc(attendanceId).set({
        'studentId': userId,
        'date': today,
        'status': 1,
        'markedBy': 'Self-Scan Simulation',
        'markedAt': FieldValue.serverTimestamp(),
        'course': course,
        'markedVia': 'QR Bypass Simulation',
      });

      // Show success dialog
      if (mounted) {
        showDialog(
          context: context,
          builder: (dialogCtx) => AlertDialog(
            title: Row(
              children: const [
                Icon(Icons.check_circle, color: Colors.green),
                SizedBox(width: 8),
                Text('Attendance Recorded!'),
              ],
            ),
            content: Text('Succesfully marked PRESENT for $today.\nYou can now check "$course" in My Attendance!'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogCtx),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Simulation failed: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('My Attendance QR Code')),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.qr_code_scanner, size: 80, color: Colors.blue),
              const SizedBox(height: 20),
              const Text('Show this QR code to your teacher', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 30),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5))],
                ),
                child: QrImageView(data: _qrData, version: QrVersions.auto, size: 250, backgroundColor: Colors.white),
              ),
              const SizedBox(height: 30),
              Text(
                'Date: ${_getDataField(\'date\')}\nName: ${_getDataField(\'name\')}\nRoll: ${_getDataField(\'rollNumber\')}\nCourse: ${_getDataField(\'course\')}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _simulateAttendanceScan,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                icon: const Icon(Icons.science),
                label: const Text('🧪 Test: Direct Self-Mark Présence', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          if (_rollNumber != null && _studentName != null) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StudentAttendanceAnalyticsScreen(
                  rollNumber: _rollNumber!,
                  studentName: _studentName!,
                ),
              ),
            );
          }
        },
        icon: const Icon(Icons.analytics),
        label: const Text('My Attendance'),
      ),
    );
  }

  String _getDataField(String key) {
    if (_qrData.isEmpty) return '';
    try {
      final map = jsonDecode(_qrData);
      return map[key] ?? '';
    } catch (_) {
      return '';
    }
  }

}



