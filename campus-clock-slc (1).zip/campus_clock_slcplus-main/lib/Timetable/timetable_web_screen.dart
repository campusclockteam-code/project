import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart'; // for kIsWeb
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:printing/printing.dart';

/// Interactive Native Timetable Class Model
class TimetableItem {
  final String rawText;
  final String type; // Lecture, Tutorial, Practical
  final String subject;
  final String room;
  final String teacher;
  final String group;
  final List<String> periods;

  TimetableItem({
    required this.rawText,
    required this.type,
    required this.subject,
    required this.room,
    required this.teacher,
    required this.group,
    required this.periods,
  });

  Map<String, dynamic> toJson() {
    return {
      'rawText': rawText,
      'type': type,
      'subject': subject,
      'room': room,
      'teacher': teacher,
      'group': group,
      'periods': periods,
    };
  }

  factory TimetableItem.fromJson(Map<String, dynamic> json) {
    return TimetableItem(
      rawText: json['rawText'] ?? '',
      type: json['type'] ?? 'Lecture',
      subject: json['subject'] ?? '',
      room: json['room'] ?? 'RN--',
      teacher: json['teacher'] ?? 'Faculty',
      group: json['group'] ?? '',
      periods: List<String>.from(json['periods'] ?? []),
    );
  }
}

class TimetableWebScreen extends StatefulWidget {
  final String url;
  final String? className;
  final String? semester;
  final String? section;
  final String? teacher;
  final String? room;
  final String? day;
  final String? period;
  final String? presetName;
  final bool isOfflineDefault;

  const TimetableWebScreen({
    super.key,
    required this.url,
    this.className,
    this.semester,
    this.section,
    this.teacher,
    this.room,
    this.day,
    this.period,
    this.presetName,
    this.isOfflineDefault = false,
  });

  @override
  State<TimetableWebScreen> createState() => _TimetableWebScreenState();
}

class _TimetableWebScreenState extends State<TimetableWebScreen> with TickerProviderStateMixin {
  late WebViewController _controller;
  int _loadingPercentage = 0;
  bool _isLoading = true;
  bool _hasError = false;
  String _errorMessage = '';
  Timer? _loadTimeoutTimer;
  bool _formSubmitted = false;
  bool _autoFillAttempted = false;
  bool _manualFillMode = false;
  String _currentUrl = '';
  bool _isWebViewControllerInitialized = false;

  // View Mode Settings
  bool _isNativeView = true;
  bool _isBookmarked = false;

  // Parsed Timetable State Data
  List<String> _listPeriods = [];
  Map<String, List<TimetableItem>> _parsedDaysData = {};
  List<String> _availableDays = [];
  String _selectedDay = 'Monday';
  String _searchFilterQuery = '';
  Map<String, String> _dynamicTeacherCodes = {};

  // Animations helpers
  late TabController _dayTabController;

  @override
  void initState() {
    super.initState();
    _currentUrl = widget.url;

    // Default TabController with a single element, will be re-initialized once data loads
    _dayTabController = TabController(length: 1, vsync: this);

    if (widget.isOfflineDefault) {
      _loadOfflineDefaultSchedule();
    } else {
      _checkBookmarkStatus();
      if (kIsWeb) {
        // Direct API loading on Web platform
        _fetchViaHTTPAPIServer();
      } else {
        // Webview loading with JS scraping on Android/iOS
        _initializeWebView();
      }
    }
  }

  @override
  void dispose() {
    _loadTimeoutTimer?.cancel();
    _dayTabController.dispose();
    super.dispose();
  }

  // Define dynamic server base URL relative to connection environment
  String _getApiServerBaseUrl() {
    if (kIsWeb) {
      final uri = Uri.base;
      // Extract port if running custom ports under development
      final portStr = (uri.port != 80 && uri.port != 443) ? ':${uri.port}' : '';
      return '${uri.scheme}://${uri.host}$portStr';
    } else {
      // Mobile emulator can redirect directly to localhost via 10.0.2.2 proxy
      return 'http://10.0.2.2:3000';
    }
  }

  // Load offline Default Saved Schedule from SharedPreferences
  Future<void> _loadOfflineDefaultSchedule() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
    });

    try {
      final prefs = await SharedPreferences.getInstance();
      final savedDataStr = prefs.getString('saved_default_timetable');
      if (savedDataStr != null) {
        final Map<String, dynamic> rootJson = jsonDecode(savedDataStr);
        _importJSONTimetableData(rootJson);
        setState(() {
          _isBookmarked = true;
          _isLoading = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('⚡ Loaded bookmarked timetable instantly offline!'),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
          ),
        );
      } else {
        setState(() {
          _isLoading = false;
          _hasError = true;
          _errorMessage = 'No default bookmarked timetable saved yet.';
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to load cached timetable: $e';
      });
    }
  }

  Future<void> _checkBookmarkStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = 'bookmark_${widget.className}_Sem${widget.semester}';
      setState(() {
        _isBookmarked = prefs.getBool(key) ?? false;
      });
    } catch (e) {
      debugPrint('Bookmark status read error: $e');
    }
  }

  Future<void> _toggleBookmarkStatus(BuildContext context) async {
    if (_parsedDaysData.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No timetable loaded to bookmark.')),
      );
      return;
    }

    try {
      final prefs = await SharedPreferences.getInstance();
      final keyFormat = 'bookmark_${widget.className}_Sem${widget.semester}';
      final isNewState = !_isBookmarked;

      await prefs.setBool(keyFormat, isNewState);

      // Save complete week JSON to offline storage
      final Map<String, dynamic> payload = {
        'className': widget.className,
        'semester': widget.semester,
        'periods': _listPeriods,
        'teacherCodes': _dynamicTeacherCodes,
        'grid': _parsedDaysData.map((day, items) => MapEntry(
            day, items.map((e) => e.toJson()).toList())),
      };

      final jsonPayloadStr = jsonEncode(payload);

      if (isNewState) {
        // Also save as global default offline timeline
        await prefs.setString('saved_default_timetable', jsonPayloadStr);
        await prefs.setString('saved_default_course', widget.className ?? '');
        await prefs.setString('saved_default_semester', widget.semester ?? '');
      } else {
        // Remove global default if matched
        final activeDefaultCourse = prefs.getString('saved_default_course');
        if (activeDefaultCourse == widget.className) {
          await prefs.remove('saved_default_timetable');
          await prefs.remove('saved_default_course');
          await prefs.remove('saved_default_semester');
        }
      }

      setState(() {
        _isBookmarked = isNewState;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isNewState
              ? 'Saved to default offline home! Available anytime offline.'
              : 'Removed from bookmarks.'),
          backgroundColor: isNewState ? Colors.green : Colors.grey,
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to save bookmark: $e')),
      );
    }
  }

  /// Direct API Call (mainly for instant Web loading as WebView isn't supported)
  Future<void> _fetchViaHTTPAPIServer() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
      _errorMessage = '';
    });

    try {
      final baseUrl = _getApiServerBaseUrl();
      debugPrint('Web API Connect to: $baseUrl');

      // 1. Fetch autocomplete options list to translate course names to correct ID numbers
      final optionsResponse = await http.get(Uri.parse('$baseUrl/api/timetable/options'))
          .timeout(const Duration(seconds: 8));

      String? matchedClassId;
      String? matchedSem;

      if (optionsResponse.statusCode == 200) {
        final optionsJson = jsonDecode(optionsResponse.body);
        if (optionsJson['success'] == true) {
          final List classes = optionsJson['data']['classes'] ?? [];
          final List semesters = optionsJson['data']['semesters'] ?? [];

          // Try exact or contains matching
          final matchCls = classes.firstWhere(
            (c) => c['text'].toString().trim().toLowerCase() == widget.className?.trim().toLowerCase() ||
                   c['text'].toString().trim().toLowerCase().contains(widget.className?.trim().toLowerCase() ?? 'x'),
            orElse: () => null,
          );
          if (matchCls != null) matchedClassId = matchCls['value'].toString();

          final matchSemObj = semesters.firstWhere(
            (s) => s['text'].toString().trim().toLowerCase() == widget.semester?.trim().toLowerCase() ||
                   s['text'].toString().trim() == widget.semester?.trim(),
            orElse: () => null,
          );
          if (matchSemObj != null) matchedSem = matchSemObj['value'].toString();
        }
      }

      // Fallbacks if lookup fails
      matchedClassId ??= '37'; // Default to B.Sc CS
      matchedSem ??= widget.semester ?? 'II';

      // 2. Submit values via POST to obtain parsed JSON timetable
      final submitResponse = await http.post(
        Uri.parse('$baseUrl/api/timetable/submit'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'classId': matchedClassId,
          'semester': matchedSem,
          'class_section': widget.section ?? '',
          'teacher': widget.teacher ?? '',
          'roomno': widget.room ?? '',
          'day': widget.day ?? '',
          'period': widget.period ?? '',
        }),
      ).timeout(const Duration(seconds: 15));

      if (submitResponse.statusCode == 200) {
        final resultJson = jsonDecode(submitResponse.body);
        if (resultJson['success'] == true && resultJson['hasData'] == true) {
          _importJSONTimetableData(resultJson);
          setState(() {
            _isLoading = false;
          });
        } else {
          setState(() {
            _isLoading = false;
            _hasError = true;
            _errorMessage = 'No timetable slots assigned for this search query on the Delhi University college portal.';
          });
        }
      } else {
        throw Exception('Server responded with state ${submitResponse.statusCode}');
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _hasError = true;
        _errorMessage = 'Failed to connect to Delhi University portal server. The gateway is slow. Switch to Official Web Portal.';
      });
      debugPrint('HTTP API Scraping failed: $e');
    }
  }

  // Common loader to map parsed JSON structures to typed state variables
  void _importJSONTimetableData(Map<String, dynamic> rawJson) {
    _listPeriods = List<String>.from(rawJson['periods'] ?? []);

    // Load dynamic teacher definitions inside scraper
    if (rawJson['teacherCodes'] != null) {
      _dynamicTeacherCodes = Map<String, String>.from(rawJson['teacherCodes']);
    }

    final parsedGrid = <String, List<TimetableItem>>{};

    if (rawJson['grid'] != null) {
      // Dynamic grid returned by API or saved offline default
      final dynamic rawGrid = rawJson['grid'];
      if (rawGrid is List) {
        // API format
        for (final item in rawGrid) {
          final String day = item['day'] ?? '';
          final List rawCells = item['cells'] ?? [];
          final List<TimetableItem> dayEntries = [];

          for (final cell in rawCells) {
            final List entries = cell['entries'] ?? [];
            final List<String> associatedPeriods = List<String>.from(cell['associatedPeriods'] ?? []);

            for (final entry in entries) {
              dayEntries.add(TimetableItem(
                rawText: entry['raw'] ?? '',
                type: entry['type'] ?? 'Lecture',
                subject: entry['subject'] ?? '',
                room: entry['room'] ?? 'RN--',
                teacher: entry['expandedTeacher'] ?? entry['teacher'] ?? 'Faculty',
                group: entry['group'] ?? '',
                periods: associatedPeriods,
              ));
            }
          }
          if (dayEntries.isNotEmpty) {
            parsedGrid[day] = dayEntries;
          }
        }
      } else if (rawGrid is Map) {
        // Saved JSON format
        rawGrid.forEach((key, value) {
          final List listRaw = value as List;
          parsedGrid[key.toString()] = listRaw.map((e) => TimetableItem.fromJson(Map<String, dynamic>.from(e))).toList();
        });
      }
    }

    setState(() {
      _parsedDaysData = parsedGrid;
      _availableDays = parsedGrid.keys.toList();
      if (_availableDays.isNotEmpty) {
        // Highlight current day if available
        final todayIndex = DateTime.now().weekday;
        const indexToDaysMap = {
          1: 'Monday',
          2: 'Tuesday',
          3: 'Wednesday',
          4: 'Thursday',
          5: 'Friday',
          6: 'Saturday',
          7: 'Sunday'
        };
        final String currentDayStr = indexToDaysMap[todayIndex] ?? 'Monday';
        if (_availableDays.contains(currentDayStr)) {
          _selectedDay = currentDayStr;
        } else {
          _selectedDay = _availableDays.first;
        }

        // Initialize TabController
        _dayTabController.dispose();
        _dayTabController = TabController(
          length: _availableDays.length,
          initialIndex: _availableDays.indexOf(_selectedDay),
          vsync: this
        );
        _dayTabController.addListener(() {
          if (!mounted) return;
          setState(() {
            _selectedDay = _availableDays[_dayTabController.index];
          });
        });
      }
    });
  }

  // Local Webview Parser execution and Javascript triggers
  Future<void> _initializeWebView() async {
    try {
      _controller = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(Colors.white)
        ..addJavaScriptChannel(
          'TimetableParserChannel',
          onMessageReceived: (JavaScriptMessage message) {
            _handleJsParsedData(message.message);
          },
        )
        ..setNavigationDelegate(
          NavigationDelegate(
            onPageStarted: (url) {
              _currentUrl = url;
              if (mounted) {
                setState(() {
                  _isLoading = true;
                  _loadingPercentage = 0;
                  _hasError = false;
                });
              }

              _loadTimeoutTimer?.cancel();
              _loadTimeoutTimer = Timer(const Duration(seconds: 40), () {
                if (mounted && _isLoading) {
                  setState(() {
                    _hasError = true;
                    _errorMessage = 'Request Timeout. The Delhi University college portal took too long to load.';
                    _isLoading = false;
                  });
                }
              });
            },
            onProgress: (progress) {
              if (mounted) setState(() => _loadingPercentage = progress);
            },
            onPageFinished: (url) async {
              _loadTimeoutTimer?.cancel();
              _currentUrl = url;
              if (mounted) setState(() => _loadingPercentage = 100);

              // Pause briefly for AJAX layouts
              await Future.delayed(const Duration(seconds: 2));

              // Run form filling or extraction
              await _evaluatePageContents();
            },
            onWebResourceError: (error) {
              _loadTimeoutTimer?.cancel();
              // HTTP 302 or common platform warning overrides
              if (error.description.contains('net::ERR_CLEARTEXT_NOT_PERMITTED')) {
                if (mounted) {
                  setState(() {
                    _isLoading = false;
                    _hasError = true;
                    _errorMessage = 'Cleartext secure warning. Please verify HTTPS configurations or allow non-HTTPS.';
                  });
                }
              }
            },
            onNavigationRequest: (navigation) {
              _currentUrl = navigation.url;
              return NavigationDecision.navigate;
            },
          ),
        )
        ..enableZoom(true)
        ..setUserAgent(
          'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36',
        );

      _isWebViewControllerInitialized = true;
      await _controller.loadRequest(Uri.parse(widget.url));
    } catch (e) {
      if (mounted) {
        setState(() {
          _hasError = true;
          _errorMessage = 'Failed to initialize WebView framework: $e';
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _evaluatePageContents() async {
    if (!mounted) return;
    try {
      // Evaluate if timetable table is present on screen
      final checkJs = '''
        (function() {
          const bodyText = document.body.innerText;
          const tableExists = document.querySelectorAll('table').length > 0 && 
            (bodyText.includes('Monday') || bodyText.includes('Tuesday') || bodyText.includes('Subject'));
          const isEmptyMessage = bodyText.includes('No Data Found...!');
          
          if (tableExists) return 'timetable_loaded';
          if (isEmptyMessage) return 'no_data_found';
          return 'form_view';
        })()
      ''';

      final String pageState = await _controller.runJavaScriptReturningResult(checkJs) as String;
      final cleanState = pageState.replaceAll('"', '').trim();

      debugPrint('Internal Page State: $cleanState');

      if (cleanState == 'timetable_loaded') {
        _formSubmitted = true;
        await _scrapeTimetableFromWebView();
      } else if (cleanState == 'no_data_found') {
        _formSubmitted = true;
        setState(() {
          _isLoading = false;
          _hasError = true;
          _errorMessage = 'No schedule data found for this class on Shyam Lal College servers.';
        });
      } else {
        // Still on Form View - Auto fill details
        if (!_autoFillAttempted && !_manualFillMode) {
          await _performSLCFormFillInWebView();
        } else {
          setState(() {
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      debugPrint('Page analysis error: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _performSLCFormFillInWebView() async {
    _autoFillAttempted = true;

    String escapeJsStr(String? value) => value == null ? 'null' : jsonEncode(value);

    final jsInject = '''
      (function() {
        function selectOptionByText(selectId, valueText) {
          try {
            const select = document.getElementById(selectId);
            if (!select || !valueText) return false;
            const targetText = valueText.toString().trim().toLowerCase();
            
            for (let i = 0; i < select.options.length; i++) {
              const optionText = select.options[i].text.trim().toLowerCase();
              if (optionText === targetText || optionText.includes(targetText) || targetText.includes(optionText)) {
                select.selectedIndex = i;
                ['change', 'input', 'blur'].forEach(ev => {
                  select.dispatchEvent(new Event(ev, { bubbles: true }));
                });
                return true;
              }
            }
            return false;
          } catch(e) {
            return false;
          }
        }
        
        let fills = 0;
        ${widget.className != null ? "if (selectOptionByText('classid', ${escapeJsStr(widget.className)})) fills++;" : ""}
        ${widget.semester != null ? "if (selectOptionByText('semester', ${escapeJsStr(widget.semester)})) fills++;" : ""}
        ${widget.section != null ? "if (selectOptionByText('class_section', ${escapeJsStr(widget.section)})) fills++;" : ""}
        ${widget.teacher != null ? "if (selectOptionByText('teacher', ${escapeJsStr(widget.teacher)})) fills++;" : ""}
        ${widget.room != null ? "if (selectOptionByText('roomno', ${escapeJsStr(widget.room)})) fills++;" : ""}
        ${widget.day != null ? "if (selectOptionByText('day', ${escapeJsStr(widget.day)})) fills++;" : ""}
        ${widget.period != null ? "if (selectOptionByText('period', ${escapeJsStr(widget.period)})) fills++;" : ""}
        
        if (fills >= 2) {
          setTimeout(function() {
            const submits = document.querySelectorAll('input[type="submit"], button[type="submit"], input[name="submit"]');
            if (submits.length > 0) {
              submits[0].click();
            } else if (document.forms.length > 0) {
              document.forms[0].submit();
            }
          }, 1200);
          return 'submitting';
        }
        return 'failed_matches';
      })();
    ''';

    try {
      final String actionRes = await _controller.runJavaScriptReturningResult(jsInject) as String;
      final cleanActionRes = actionRes.replaceAll('"', '').trim();

      debugPrint('AutoFill Form Trigger Answer: $cleanActionRes');

      if (cleanActionRes == 'submitting') {
        setState(() {
          _formSubmitted = true;
          _isLoading = true;
        });
      } else {
        _manualFillMode = true;
        setState(() {
          _isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not match autocomplete selectors. Please configure selection manually.'),
            backgroundColor: Colors.orange,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      debugPrint('Auto fill scripts crash: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _scrapeTimetableFromWebView() async {
    final scrapeJs = '''
      (function() {
        try {
          const tables = document.querySelectorAll('table');
          let mainTable = null;
          for (const t of tables) {
            const inner = t.innerText;
            if (inner.includes('Monday') || inner.includes('Tuesday') || inner.includes('Wednesday')) {
              mainTable = t;
              break;
            }
          }
          if (!mainTable) {
            return JSON.stringify({ success: false, reason: 'Grid table unavailable' });
          }
          
          // Parse Header timeline slots
          const rows = mainTable.querySelectorAll('tr');
          if (rows.length < 2) {
            return JSON.stringify({ success: false, reason: 'Empty schedule rows' });
          }
          
          const periods = [];
          const headerCells = rows[0].querySelectorAll('td');
          for (let i = 1; i < headerCells.length; i++) {
            periods.push(headerCells[i].innerText.trim());
          }
          
          // Parse rows
          const parsedGridDay = [];
          for (let r = 1; r < rows.length; r++) {
            const tr = rows[r];
            const cells = tr.querySelectorAll('td');
            if (cells.length === 0) continue;
            
            const dayName = cells[0].innerText.trim();
            const cellsList = [];
            
            for (let c = 1; c < cells.length; c++) {
              const cell = cells[c];
              const textContent = cell.innerText.trim();
              const colspanVal = parseInt(cell.getAttribute('colspan') || '1', 10);
              
              cellsList.push({
                colspan: colspanVal,
                cleanText: textContent
              });
            }
            parsedGridDay.push({
              day: dayName,
              cells: cellsList
            });
          }
          
          // Dictionary parsing for dynamic abbreviated codes in footer
          const teacherCodesMap = {};
          const bodyText = document.body.innerText;
          const endTableIndex = bodyText.indexOf('Lectures :');
          if (endTableIndex !== -1) {
            const footerString = bodyText.substring(endTableIndex);
            const items = footerString.split(',');
            items.forEach(item => {
              const matchedCode = item.trim().match(/^([A-Z0-9\\s]+)\\s*-\\s*([^(]+)/i);
              if (matchedCode) {
                const code = matchedCode[1].trim().toUpperCase();
                const fullName = matchedCode[2].trim();
                teacherCodesMap[code] = fullName;
              }
            });
          }
          
          return JSON.stringify({
            success: true,
            periods: periods,
            grid: parsedGridDay,
            teacherCodes: teacherCodesMap
          });
        } catch(e) {
          return JSON.stringify({ success: false, error: e.toString() });
        }
      })()
    ''';

    try {
      final String rawScrapeJson = await _controller.runJavaScriptReturningResult(scrapeJs) as String;
      _handleJsParsedData(rawScrapeJson);
    } catch (e) {
      debugPrint('WebView JS scrape crash: $e');
      setState(() => _isLoading = false);
    }
  }

  void _handleJsParsedData(String payloadStr) {
    try {
      // Decode potential string double encoding returned by platforms
      String cleanStr = payloadStr;
      if (payloadStr.startsWith('"') && payloadStr.endsWith('"')) {
        cleanStr = jsonDecode(payloadStr);
      }

      final Map<String, dynamic> rawJson = jsonDecode(cleanStr);
      if (rawJson['success'] == true) {
        _importJSONTimetableData(rawJson);
        setState(() {
          _isLoading = false;
        });
      } else {
        setState(() {
          _isLoading = false;
          _hasError = true;
          _errorMessage = rawJson['reason'] ?? 'Could not parse timetable schedule table structure.';
        });
      }
    } catch (e) {
      debugPrint('Parsing of Javascript answer failed: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _refreshPage() async {
    setState(() {
      _isLoading = true;
      _hasError = false;
      _formSubmitted = false;
      _autoFillAttempted = false;
      _manualFillMode = false;
      _parsedDaysData.clear();
      _availableDays.clear();
    });

    if (kIsWeb) {
      await _fetchViaHTTPAPIServer();
    } else {
      await _controller.reload();
    }
  }

  // Parse custom text strings to create structured Cards elements
  List<TimetableItem> _getFilteredDayLectures() {
    final rawList = _parsedDaysData[_selectedDay] ?? [];

    // Local split parser for multiple classes inside the same cell if WebView didn't expand
    final List<TimetableItem> expandedItems = [];

    for (final rawItem in rawList) {
      final text = rawItem.rawText;
      if (text.isEmpty) continue;

      // Check standard multiple records patterns separated by 5+ underscores
      final individualSegments = text.split(RegExp(r'_{5,}'))
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();

      if (individualSegments.length > 1) {
        for (final seg in individualSegments) {
          expandedItems.add(_parseTextSegmentToItem(seg, rawItem.periods));
        }
      } else {
        expandedItems.add(_parseTextSegmentToItem(text, rawItem.periods));
      }
    }

    // Filter list using search query
    if (_searchFilterQuery.isNotEmpty) {
      return expandedItems.where((l) {
        final query = _searchFilterQuery.toLowerCase();
        return l.subject.toLowerCase().contains(query) ||
               l.teacher.toLowerCase().contains(query) ||
               l.room.toLowerCase().contains(query);
      }).toList();
    }

    return expandedItems;
  }

  TimetableItem _parseTextSegmentToItem(String segmentText, List<String> currentPeriods) {
    // Session Lecture type
    String type = 'Lecture';
    if (segmentText.startsWith('T-')) {
      type = 'Tutorial';
    } else if (segmentText.startsWith('P-') || segmentText.toLowerCase().contains('lab') || segmentText.toLowerCase().contains('practical')) {
      type = 'Practical';
    }

    // Strip out typings code prefixes (e.g., L-, T-, P-)
    String scrubbed = segmentText;
    final typePrefixMatch = RegExp(r'^(L|T|P)-\d*\.?\s*', caseSensitive: false).firstMatch(scrubbed);
    if (typePrefixMatch != null) {
      scrubbed = scrubbed.substring(typePrefixMatch.end);
    }

    // Check custom Groups suffixes (e.g., -G1, -G2)
    String classGroup = '';
    final groupMatch = RegExp(r'-G(\d+)$', caseSensitive: false).firstMatch(scrubbed);
    if (groupMatch != null) {
      classGroup = 'Group ' + groupMatch.group(1)!;
      scrubbed = scrubbed.replaceAll(RegExp(r'-G(\d+)$', caseSensitive: false), '');
    }

    // Parse segments inside remaining string
    final segments = scrubbed.split('-').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();
    String subjectVal = scrubbed;
    String roomVal = widget.room ?? 'RN--';
    String teacherVal = widget.teacher ?? 'Faculty Staff';

    if (segments.length == 1) {
      subjectVal = segments[0];
    } else if (segments.length == 2) {
      subjectVal = segments[0];
      final secondarySegment = segments[1];
      if (secondarySegment.toUpperCase().startsWith('RN') || RegExp(r'^\d+$').hasMatch(secondarySegment)) {
        roomVal = secondarySegment;
      } else {
        teacherVal = secondarySegment;
      }
    } else if (segments.length == 3) {
      subjectVal = segments[0];
      roomVal = segments[1];
      teacherVal = segments[2];
    } else if (segments.length >= 4) {
      teacherVal = segments.last;
      roomVal = segments[segments.length - 2];
      subjectVal = segments.sublist(0, segments.length - 2).join('-');
    }

    // Auto expand short abbreviations codes in teacher name (e.g., "KM" -> "Dr. Kinshuk Majumdar")
    final String cleanTeacherKey = teacherVal.replaceAll(RegExp(r'\s+'), '').toUpperCase();
    if (_dynamicTeacherCodes.containsKey(cleanTeacherKey)) {
      teacherVal = _dynamicTeacherCodes[cleanTeacherKey]!;
    } else {
      // Static lookup matching support for standard Shyam Lal teachers
      final staticKnownTeachers = {
        'KM': 'Dr. Kinshuk Majumdar',
        'RS': 'Dr. Reeta Sharma',
        'SG': 'Dr. Seema Guglani',
        'SM': 'Dr. Srinivas Misra',
        'MK': 'Ms. Manila Kohli',
        'PG': 'Dr. Pooja Gupta',
        'YM': 'Dr. Yukti Monga',
        'AG': 'Prof. Arkaja Goswami',
        'HG': 'Prof. Hemant Kukreti',
        'RNK': 'Prof. Rabi Narayan Kar',
      };
      if (staticKnownTeachers.containsKey(cleanTeacherKey)) {
        teacherVal = staticKnownTeachers[cleanTeacherKey]!;
      }
    }

    return TimetableItem(
      rawText: segmentText,
      type: type,
      subject: subjectVal,
      room: roomVal,
      teacher: teacherVal,
      group: classGroup,
      periods: currentPeriods,
    );
  }

  Color _getSessionTypeColor(String type) {
    switch (type) {
      case 'Practical':
        return Colors.emerald;
      case 'Tutorial':
        return Colors.amber.shade700;
      default:
        return Colors.blue;
    }
  }

  // Calculate if a specific class is currently running right now!
  bool _isClassCurrentlyRunning(List<String> activePeriods) {
    if (activePeriods.isEmpty) return false;

    // Must match the actual calendar day of week
    final todayIndex = DateTime.now().weekday;
    const indexToDaysMap = {
      1: 'Monday',
      2: 'Tuesday',
      3: 'Wednesday',
      4: 'Thursday',
      5: 'Friday',
      6: 'Saturday',
      7: 'Sunday'
    };
    if (indexToDaysMap[todayIndex] != _selectedDay) return false;

    try {
      final now = DateTime.now();

      // Parse the period times, typical format: "8:00 - 9:00" or similar
      final cleanPeriod = activePeriods.first.replaceAll(RegExp(r'\s+'), '');
      final subTimes = cleanPeriod.split('-');
      if (subTimes.length < 2) return false;

      final startPart = subTimes[0];
      final endPart = subTimes[1];

      // helper to parse hours and minutes
      DateTime _getDateTimeFromPart(String p) {
        final t = p.split(':');
        int h = int.parse(t[0]);
        final m = int.parse(t[1]);

        // Adjust for standard Shyamlal PM periods (e.g. 1:00, 2:00, 3:00 correspond to 13:00, 14:00, 15:00)
        if (h >= 1 && h <= 5) {
          h += 12;
        }

        return DateTime(now.year, now.month, now.day, h, m);
      }

      final startDT = _getDateTimeFromPart(startPart);
      final endDT = _getDateTimeFromPart(endPart);

      return now.isAfter(startDT) && now.isBefore(endDT);
    } catch (e) {
      return false;
    }
  }

  /// Exports current parsed week schedule into a elegantly formatted, printable HTML layout
  Future<void> _exportScheduleToPDF() async {
    if (_parsedDaysData.isEmpty) return;

    final String className = widget.className ?? 'Shyam Lal College';
    final String semester = widget.semester ?? 'II';

    // Build the grid dynamic tables
    StringBuffer rowsHtmlBuffer = StringBuffer();

    for (final day in _parsedDaysData.keys) {
      final entries = _parsedDaysData[day] ?? [];
      for (final entry in entries) {
        final itemDetails = _parseTextSegmentToItem(entry.rawText, entry.periods);
        final periodsJoined = itemDetails.periods.join(', ');
        rowsHtmlBuffer.write('''
          <tr>
            <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold; color: #1e1b4b;">$day</td>
            <td style="padding: 10px; border: 1px solid #ddd; font-family: monospace;">$periodsJoined</td>
            <td style="padding: 10px; border: 1px solid #ddd; font-weight: 500;">${itemDetails.subject}</td>
            <td style="padding: 10px; border: 1px solid #ddd; color: #10b981; font-weight: bold;">${itemDetails.type}</td>
            <td style="padding: 10px; border: 1px solid #ddd;">${itemDetails.teacher}</td>
            <td style="padding: 10px; border: 1px solid #ddd; text-align: center;"><span style="background-color: #f3f4f6; padding: 4px 8px; border-radius: 4px; font-weight: bold; font-family: monospace;">${itemDetails.room}</span></td>
          </tr>
        ''');
      }
    }

    final printableHtml = '''
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>$className Timetable</title>
      <style>
        body { font-family: 'Helvetica Neue', Arial, sans-serif; color: #333; padding: 20px; }
        .header { border-bottom: 3px double #1e1b4b; padding-bottom: 12px; margin-bottom: 24px; text-align: center; }
        .title { font-size: 24px; font-weight: bold; color: #1e1b4b; text-transform: uppercase; margin: 0; }
        .subtitle { font-size: 14px; color: #666; margin: 5px 0 0 0; }
        .meta-info { display: flex; justify-content: space-between; margin-bottom: 20px; font-size: 13px; background: #f8fafc; padding: 10px; border-radius: 6px; border: 1px solid #e2e8f0; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; background: #fff; }
        th { background-color: #1e1b4b; color: white; padding: 12px 10px; border: 1px solid #1e1b4b; text-align: left; font-size: 12px; text-transform: uppercase; }
        td { font-size: 13px; }
        .footer { margin-top: 40px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; padding-top: 10px; }
      </style>
    </head>
    <body>
      <div class="header">
        <h1 class="title">Shyam Lal College (SLC)</h1>
        <p class="subtitle">University Of Delhi • Campus Clock Academic Scheduler</p>
      </div>
      
      <div class="meta-info">
        <div><strong>Course:</strong> $className</div>
        <div><strong>Semester:</strong> Sem $semester</div>
        <div><strong>Date Printed:</strong> ${DateTime.now().toString().substring(0, 10)}</div>
      </div>
      
      <table>
        <thead>
          <tr>
            <th style="width: 12%;">Day</th>
            <th style="width: 18%;">Timings</th>
            <th style="width: 32%;">Subject</th>
            <th style="width: 12%;">Type</th>
            <th style="width: 18%;">Teacher</th>
            <th style="width: 8%; text-align: center;">Room</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtmlBuffer.toString()}
        </tbody>
      </table>
      
      <div class="footer">
        Generated automatically via Campus Clock SLC Academic Communicator App. All rights reserved.
      </div>
    </body>
    </html>
    ''';

    try {
      await Printing.layoutPdf(
        onLayout: (format) async => await Printing.convertHtml(
          format: format,
          html: printableHtml,
        ),
        name: '${className}_Sem${semester}_Timetable.pdf',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not generate PDF: $e')),
        );
      }
    }
  }

  /// Share current day's complete schedule via native messenger share
  void _shareDaySchedule() {
    final list = _getFilteredDayLectures();
    if (list.isEmpty) return;

    StringBuffer buffer = StringBuffer();
    buffer.writeln('📅 *SLC Timetable for $_selectedDay*');
    buffer.writeln('🎓 *Course:* ${widget.className} (Sem ${widget.semester})');
    buffer.writeln('------------------------------------------');

    for (final item in list) {
      buffer.writeln('🕒 *${item.periods.join(", ")}*');
      buffer.writeln('📚 *Subject:* ${item.subject} (${item.type})');
      buffer.writeln('👤 *Teacher:* ${item.teacher}');
      buffer.writeln('🏢 *Room No:* ${item.room}');
      if (item.group.isNotEmpty) buffer.writeln('👥 *Group:* ${item.group}');
      buffer.writeln('------------------------------------------');
    }

    buffer.writeln('\n📱 shared via Campus Clock Shyam Lal College app.');

    Share.share(buffer.toString());
  }

  @override
  Widget build(BuildContext context) {
    // Hide original web views totally on Flutter Web environment
    final canToggleView = !kIsWeb && !widget.isOfflineDefault && _isWebViewControllerInitialized;

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              widget.presetName ?? 'Campus Clock Timetable',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            if (widget.className != null)
              Text(
                '${widget.className} ${widget.semester != null ? "Sem ${widget.semester}" : ""}',
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.normal, color: Colors.black54),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
          ],
        ),
        actions: [
          if (_parsedDaysData.isNotEmpty) ...[
            IconButton(
              icon: Icon(_isBookmarked ? Icons.bookmark : Icons.bookmark_border, color: _isBookmarked ? Colors.amber[700] : null),
              onPressed: () => _toggleBookmarkStatus(context),
              tooltip: 'Bookmark offline',
            ),
            IconButton(
              icon: const r'print' == 'print' ? const Icon(Icons.picture_as_pdf) : const Icon(Icons.print),
              onPressed: _exportScheduleToPDF,
              tooltip: 'Print PDF',
            ),
            IconButton(
              icon: const Icon(Icons.share_outlined),
              onPressed: _shareDaySchedule,
              tooltip: 'Share schedule',
            ),
          ],
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshPage,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: Column(
        children: [
          // Segmented controller for Mobile views supporting real browser toggle
          if (canToggleView)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(4),
                child: Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () => setState(() => _isNativeView = true),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            color: _isNativeView ? Colors.white : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: _isNativeView
                                ? [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4, offset: const Offset(0, 2))]
                                : [],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.dashboard, size: 16, color: _isNativeView ? Colors.blue : Colors.grey[600]),
                              const SizedBox(width: 8),
                              Text(
                                'Native Schedule',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: _isNativeView ? FontWeight.bold : FontWeight.normal,
                                  color: _isNativeView ? Colors.blue : Colors.grey[700],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () => setState(() => _isNativeView = false),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            color: !_isNativeView ? Colors.white : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: !_isNativeView
                                ? [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 4, offset: const Offset(0, 2))]
                                : [],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.language, size: 16, color: !_isNativeView ? Colors.blue : Colors.grey[600]),
                              const SizedBox(width: 8),
                              Text(
                                'Official Portal',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: !_isNativeView ? FontWeight.bold : FontWeight.normal,
                                  color: !_isNativeView ? Colors.blue : Colors.grey[700],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          Expanded(
            child: _isNativeView ? _buildNativeInterlacedView() : _buildWebViewInterface(),
          ),
        ],
      ),
    );
  }

  Widget _buildNativeInterlacedView() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              value: _loadingPercentage < 100 ? _loadingPercentage / 100.0 : null,
              valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
              strokeWidth: 4,
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                _formSubmitted
                    ? 'Synchronizing university timetable database ...'
                    : 'Connecting to Shyam Lal College server ...',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'This takes approximately 10-15 seconds.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            if (!kIsWeb && _loadingPercentage > 0) ...[
              const SizedBox(height: 16),
              Text(
                '$_loadingPercentage%',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue),
              ),
            ]
          ],
        ),
      );
    }

    if (_hasError) {
      return Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.cloud_off, size: 80, color: Colors.red[300]),
              const SizedBox(height: 24),
              const Text(
                'Connection Pending',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 12),
              Text(
                _errorMessage,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14, color: Colors.grey[700], height: 1.4),
              ),
              const SizedBox(height: 32),
              ElevatedButton.icon(
                onPressed: _refreshPage,
                icon: const Icon(Icons.refresh),
                label: const Text('Retry connection'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              if (!kIsWeb && !widget.isOfflineDefault) ...[
                const SizedBox(height: 16),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _isNativeView = false;
                    });
                  },
                  child: const Text('Load official Portal website manually'),
                ),
              ],
            ],
          ),
        ),
      );
    }

    // Filter day list items
    final list = _getFilteredDayLectures();

    return Column(
      children: [
        // Pill horizontal selector day of week
        if (_availableDays.isNotEmpty)
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: TabBar(
              controller: _dayTabController,
              isScrollable: true,
              tabAlignment: TabAlignment.start,
              indicator: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.blue[800],
              ),
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: Colors.transparent,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.grey[700],
              labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.normal, fontSize: 13),
              tabs: _availableDays.map((d) {
                return Tab(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Text(d),
                  ),
                );
              }).toList(),
            ),
          )
        else
          const SizedBox.shrink(),

        // Dynamic Filtering searchbar
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            onChanged: (v) => setState(() => _searchFilterQuery = v),
            decoration: InputDecoration(
              hintText: 'Filter by subject or teacher name...',
              prefixIcon: const Icon(Icons.search, size: 20),
              isDense: true,
              fillColor: Colors.white,
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide(color: Colors.grey[300]!),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Colors.blue, width: 1.5),
              ),
            ),
          ),
        ),

        // Timeline item rows list
        Expanded(
          child: list.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.coffee, size: 72, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text(
                        _searchFilterQuery.isNotEmpty ? 'No classes match your query.' : 'No lectures scheduled today! 😎',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.grey),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _searchFilterQuery.isNotEmpty ? 'Try clearing your search filters.' : 'Enjoy your academic breaks!',
                        style: const TextStyle(fontSize: 13, color: Colors.grey),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                  physics: const BouncingScrollPhysics(),
                  itemCount: list.length,
                  itemBuilder: (context, i) {
                    final item = list[i];
                    final isNow = _isClassCurrentlyRunning(item.periods);

                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: isNow ? Colors.green.shade400 : Colors.transparent,
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(isNow ? 0.08 : 0.03),
                            blurRadius: isNow ? 14 : 8,
                            spreadRadius: 2,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: IntrinsicHeight(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              // Type indicator left colored bar
                              Container(
                                width: 6,
                                color: _getSessionTypeColor(item.type),
                              ),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.between,
                                        children: [
                                          // Period Timing Badge
                                          Row(
                                            children: [
                                              const Icon(Icons.access_time_filled, size: 14, color: Colors.grey),
                                              const SizedBox(width: 6),
                                              Text(
                                                item.periods.join(', '),
                                                style: const TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey,
                                                ),
                                              ),
                                            ],
                                          ),
                                          if (isNow)
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: Colors.green.shade100,
                                                borderRadius: BorderRadius.circular(8),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Container(
                                                    width: 6,
                                                    height: 6,
                                                    decoration: const BoxDecoration(
                                                      color: Colors.green,
                                                      shape: BoxShape.circle,
                                                    ),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    'NOW RUNNING',
                                                    style: TextStyle(
                                                      fontSize: 10,
                                                      fontWeight: FontWeight.bold,
                                                      color: Colors.green.shade800,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            )
                                          else
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: _getSessionTypeColor(item.type).withOpacity(0.1),
                                                borderRadius: BorderRadius.circular(8),
                                              ),
                                              child: Text(
                                                item.type.toUpperCase(),
                                                style: TextStyle(
                                                  fontSize: 9,
                                                  fontWeight: FontWeight.bold,
                                                  color: _getSessionTypeColor(item.type),
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),
                                      // Subject Theme Name
                                      Text(
                                        item.subject,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black87,
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      const Divider(height: 1, color: Colors.black12),
                                      const SizedBox(height: 10),

                                      // Teacher card profile row
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.between,
                                        children: [
                                          Expanded(
                                            child: Row(
                                              children: [
                                                const Icon(Icons.person, size: 16, color: Colors.blueGrey),
                                                const SizedBox(width: 8),
                                                Expanded(
                                                  child: Text(
                                                    item.teacher,
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                    style: const TextStyle(
                                                      fontSize: 13,
                                                      color: Colors.black54,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          // Room Number badge
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: Colors.grey[200],
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: textWidgetAndIconRow(item.room),
                                          )
                                        ],
                                      ),
                                      if (item.group.isNotEmpty) ...[
                                        const SizedBox(height: 6),
                                        Row(
                                          children: [
                                            const Icon(Icons.group_work, size: 14, color: Colors.blueGrey),
                                            const SizedBox(width: 8),
                                            Text(
                                              item.group,
                                              style: TextStyle(
                                                fontSize: 11,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.blue[800],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ]
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget textWidgetAndIconRow(String rText) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.place, size: 12, color: Colors.black54),
        const SizedBox(width: 4),
        Text(
          rText,
          style: const TextStyle(
            fontSize: 11,
            fontFamily: 'monospace',
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }

  Widget _buildWebViewInterface() {
    return Stack(
      children: [
        Column(
          children: [
            if (_isLoading && _loadingPercentage < 100)
              LinearProgressIndicator(
                value: _loadingPercentage / 100.0,
                backgroundColor: Colors.grey[200],
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                minHeight: 3,
              ),
            Expanded(
              child: WebViewWidget(controller: _controller),
            ),
          ],
        ),
        if (_isLoading && _loadingPercentage < 100)
          Container(
            color: Colors.white.withOpacity(0.8),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(value: _loadingPercentage / 100.0, strokeWidth: 4),
                  const SizedBox(height: 16),
                  Text(
                    _formSubmitted ? 'Submitting query to server...' : 'Loading portal website...',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}
