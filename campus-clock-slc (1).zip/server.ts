import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

// Raw scraping helper to extract options from slc.collegett.in HTML
function parseOptionsBySelectId(selectId: string, html: string): { value: string; text: string }[] {
  const selectRegex = new RegExp(`<select[^>]*id="${selectId}"[^>]*>([\\s\\S]*?)<\\/select>`, 'i');
  const match = selectRegex.exec(html);
  if (!match) return [];
  const optionsHtml = match[1];
  const optionRegex = /<option[^>]*value="([^"]*)"[^>]*>([\s\S]*?)<\/option>/gi;
  const options: { value: string; text: string }[] = [];
  let optMatch;
  while ((optMatch = optionRegex.exec(optionsHtml)) !== null) {
    const value = optMatch[1].trim();
    const text = optMatch[2]
      .replace(/<[^>]*>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    // Ignore the default placeholder options
    const isPlaceholder = text.toLowerCase().startsWith('select ') || text === '-- select --' || text === '';
    if (!isPlaceholder) {
      options.push({ value, text });
    }
  }
  return options;
}

// Scrape dynamic HTML returned after form submission
function parseTimetableTable(html: string) {
  // Check empty search state
  if (html.includes('No Data Found...!')) {
    return { hasData: false, rows: [], htmlTable: '', periods: [], grid: [], summary: { lectures: 0, tutorials: 0, labs: 0, total: 0 }, teachers: {} };
  }

  // Parse summary totals: Lectures, Tutorials, Labs, Total
  const lectures = parseInt(html.match(/Lectures\s*:\s*(\d+)/i)?.[1] || '0', 10);
  const tutorials = parseInt(html.match(/Tutorials\s*:\s*(\d+)/i)?.[1] || '0', 10);
  const labs = parseInt(html.match(/Labs\s*:\s*(\d+)/i)?.[1] || '0', 10);
  const total = parseInt(html.match(/Total\s*:\s*(\d+)/i)?.[1] || '0', 10);

  // Parse teachers definitions dictionary at bottom of screen
  const endTableTag = html.lastIndexOf('</table>');
  let footerText = '';
  if (endTableTag !== -1) {
    footerText = html.slice(endTableTag)
      .replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, '')
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  const teachers: Record<string, { name: string; subject: string }> = {};
  const teacherParts = footerText.split(',');
  teacherParts.forEach(part => {
    const cleanPart = part.trim();
    const match = /^([A-Z0-9\s]+)\s*-\s*([^(]+)\(([^)]+)\)$/i.exec(cleanPart);
    if (match) {
      const code = match[1].trim();
      const name = match[2].trim();
      const subject = match[3].trim();
      teachers[code] = { name, subject };
    } else {
      const simpleMatch = /^([A-Z0-9\s]+)\s*-\s*([^(]+)/i.exec(cleanPart);
      if (simpleMatch) {
        const code = simpleMatch[1].trim();
        const value = simpleMatch[2].trim();
        if (code.length <= 15 && value.length > 3) {
          teachers[code] = { name: value, subject: '' };
        }
      }
    }
  });

  // Find legacy result table elements
  const tableIndex = html.indexOf('<table width="" border="1" bordercolor="#000000"');
  if (tableIndex === -1) {
    return { hasData: false, rows: [], htmlTable: '', periods: [], grid: [], summary: { lectures, tutorials, labs, total }, teachers };
  }
  const tblEnd = html.indexOf('</table>', tableIndex);
  const tblHtml = html.slice(tableIndex, tblEnd + 8);

  // Extract row HTML segments
  const rowRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  const rowsHtml: string[] = [];
  let rowMatch;
  while ((rowMatch = rowRegex.exec(tblHtml)) !== null) {
    rowsHtml.push(rowMatch[1]);
  }

  if (rowsHtml.length < 2) {
    return { hasData: false, rows: [], htmlTable: '', periods: [], grid: [], summary: { lectures, tutorials, labs, total }, teachers };
  }

  // Parse header to get times/periods
  const headerRow = rowsHtml[0];
  const cellRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;
  let cellM;
  const periods: string[] = [];
  while ((cellM = cellRegex.exec(headerRow)) !== null) {
    const rawVal = cellM[1].replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
    if (rawVal) {
      periods.push(rawVal);
    }
  }

  // If we can't find periods, fallback to default shyamlal periods
  const finalPeriods = periods.length > 0 ? periods : ['8:00', '9:00', '10:00', '11:00', '12:00', '1:00', '2:00', '3:00', '4:00'];

  const rows: string[][] = [];
  const grid: any[] = [];

  for (let ri = 1; ri < rowsHtml.length; ri++) {
    const rowHtml = rowsHtml[ri];
    let cellM;
    const cells: { clean: string; raw: string; colspan: number }[] = [];
    const cellRegexLocal = /<td[^>]*>([\s\S]*?)<\/td>/gi; // reset regex index
    while ((cellM = cellRegexLocal.exec(rowHtml)) !== null) {
      const rawCell = cellM[0];
      const cellContent = cellM[1];

      const colspanMatch = /colspan="(\d+)"/i.exec(rawCell);
      const colspan = colspanMatch ? parseInt(colspanMatch[1], 10) : 1;

      const cleanText = cellContent
        .replace(/<style[^>]*>([\s\S]*?)<\/style>/gi, '')
        .replace(/<[^>]*>/g, '')
        .replace(/&nbsp;/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

      cells.push({
        raw: rawCell,
        clean: cleanText,
        colspan
      });
    }

    if (cells.length === 0) continue;

    const dayName = cells[0].clean; // Monday, Tuesday, etc.
    const gridCells: any[] = [];

    let periodIndex = 0;
    for (let ci = 1; ci < cells.length; ci++) {
      const cell = cells[ci];
      const associatedPeriods: string[] = [];
      for (let cs = 0; cs < cell.colspan; cs++) {
        if (periodIndex < finalPeriods.length) {
          associatedPeriods.push(finalPeriods[periodIndex]);
          periodIndex++;
        }
      }

      const entries: any[] = [];
      if (cell.clean) {
        const rawEntries = cell.clean.split(/_{5,}/g)
          .map(e => e.trim())
          .filter(e => e.length > 0);

        rawEntries.forEach(entry => {
          let type = 'Lecture';
          if (entry.startsWith('T-')) type = 'Tutorial';
          else if (entry.startsWith('P-') || entry.toLowerCase().includes('lab')) type = 'Practical';

          let textWithoutType = entry;
          const typePrefixMatch = /^(L|T|P)-\d*\.?\s*/i.exec(textWithoutType);
          if (typePrefixMatch) {
            textWithoutType = textWithoutType.slice(typePrefixMatch[0].length);
          }

          let group = '';
          const groupMatch = /-G(\d+)$/i.exec(textWithoutType);
          if (groupMatch) {
            group = `Group ${groupMatch[1]}`;
            textWithoutType = textWithoutType.replace(/-G(\d+)$/i, '');
          }

          const segments = textWithoutType.split('-').map(s => s.trim()).filter(s => s.length > 0);
          let subject = textWithoutType;
          let room = '';
          let teacher = '';

          if (segments.length === 1) {
            subject = segments[0];
          } else if (segments.length === 2) {
            subject = segments[0];
            const seg1 = segments[1];
            if (seg1.startsWith('RN') || /^\d+$/.test(seg1)) {
              room = seg1;
            } else {
              teacher = seg1;
            }
          } else if (segments.length === 3) {
            subject = segments[0];
            room = segments[1];
            teacher = segments[2];
          } else if (segments.length >= 4) {
            teacher = segments[segments.length - 1];
            room = segments[segments.length - 2];
            subject = segments.slice(0, segments.length - 2).join('-');
          }

          // Fetch the expanded teacher name if available in our dictionary
          let expandedTeacher = teacher;
          let teacherSubject = '';
          if (teacher && teachers[teacher.toUpperCase()]) {
            expandedTeacher = teachers[teacher.toUpperCase()].name;
            teacherSubject = teachers[teacher.toUpperCase()].subject;
          } else if (teacher && teachers[teacher.replace(/\s+/g, '').toUpperCase()]) {
            expandedTeacher = teachers[teacher.replace(/\s+/g, '').toUpperCase()].name;
            teacherSubject = teachers[teacher.replace(/\s+/g, '').toUpperCase()].subject;
          }

          entries.push({
            raw: entry,
            type,
            subject,
            room: room || 'RN--',
            teacher: teacher || 'Faculty',
            expandedTeacher: expandedTeacher || teacher || 'Faculty Staff',
            teacherSubject,
            group
          });

          // Also build flat list for cards display legacy code compatibility!
          // Format expected: [day, period, subject, teacher, room]
          associatedPeriods.forEach(p => {
            rows.push([dayName, p, entry, teacher || 'Faculty', room || 'RN--']);
          });
        });
      }

      gridCells.push({
        colspan: cell.colspan,
        cleanText: cell.clean,
        associatedPeriods,
        entries
      });
    }

    grid.push({
      day: dayName,
      cells: gridCells
    });
  }

  // Clean the html table to match a nice theme
  let cleanHtmlTable = tblHtml
    .replace(/bgcolor="[^"]*"/gi, '')
    .replace(/border="[^"]*"/gi, 'border="1"')
    .replace(/bordercolor="[^"]*"/gi, 'bordercolor="#1e1b4b"');

  return {
    hasData: grid.length > 0,
    periods: finalPeriods,
    grid,
    rows: rows,
    summary: { lectures, tutorials, labs, total },
    teachers,
    htmlTable: cleanHtmlTable
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // ========================================================
  // TIMETABLE SCRAPER & PROXY CONTROLLERS
  // ========================================================

  // Endpoint 1: Fetch static setup option lists (for filling the dropdowns)
  app.get('/api/timetable/options', async (req, res) => {
    try {
      console.log('Scraping options from slc.collegett.in...');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6000); // 6s timeout

      const response = await fetch('http://slc.collegett.in/', {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        }
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Collegett responded with status ${response.status}`);
      }

      const html = await response.text();

      const classes = parseOptionsBySelectId('classid', html);
      const semesters = parseOptionsBySelectId('semester', html);
      const teachers = parseOptionsBySelectId('teacher', html);
      const rooms = parseOptionsBySelectId('roomno', html);
      const days = parseOptionsBySelectId('day', html);
      const periods = parseOptionsBySelectId('period', html);

      res.json({
        success: true,
        source: 'slc.collegett.in',
        data: { classes, semesters, teachers, rooms, days, periods }
      });
    } catch (error: any) {
      console.warn('Scraping options failed. Utilizing high-fidelity academic presets as fallback:', error.message);
      
      // Gorgeous fallback data ensuring total failproof offline behavior
      res.json({
        success: true,
        source: 'local_preset',
        data: {
          classes: [
            { value: '37', text: 'B.Sc Physical Science(CS)' },
            { value: '80', text: 'B.Sc. (Physical Science Hons) Physics' },
            { value: '57', text: 'Chemistry Hons.' },
            { value: '38', text: 'B.Com.(Prog)' },
            { value: '22', text: 'B.A.(Prog.)' },
            { value: '18', text: 'B.A(H) Political Science' },
            { value: '10', text: 'B.A(H) History' },
            { value: '1', text: 'B.Com.(Hons)' },
            { value: '78', text: 'GE/SEC/VAC/DSE/AEC' }
          ],
          semesters: [
            { value: '2', text: 'II' },
            { value: '4', text: 'IV' },
            { value: '6', text: 'VI' },
            { value: '8', text: 'VIII' }
          ],
          teachers: [
            { value: '413', text: 'Dr. Kinshuk Majumdar' },
            { value: '201', text: 'Dr. Reeta Sharma' },
            { value: '131', text: 'Dr. Seema Guglani' },
            { value: '72', text: 'Dr. Srinivas Misra' },
            { value: '47', text: 'Prof. Arkaja Goswami' },
            { value: '48', text: 'Prof. Ashu Gupta' }
          ],
          rooms: [
            { value: '1', text: 'RN1' },
            { value: '10', text: 'RN10' },
            { value: '101', text: 'RN101' },
            { value: '112', text: 'RN112' },
            { value: '202', text: 'RN202' },
            { value: '203', text: 'RN203' }
          ],
          days: [
            { value: '1', text: 'Monday' },
            { value: '2', text: 'Tuesday' },
            { value: '3', text: 'Wednesday' },
            { value: '4', text: 'Thursday' },
            { value: '5', text: 'Friday' },
            { value: '6', text: 'Saturday' }
          ],
          periods: [
            { value: '1', text: '8:00' },
            { value: '2', text: '9:00' },
            { value: '3', text: '10:00' },
            { value: '4', text: '11:00' },
            { value: '5', text: '12:00' },
            { value: '6', text: '1:00' },
            { value: '7', text: '2:00' },
            { value: '8', text: '3:00' },
            { value: '9', text: '4:00' }
          ]
        }
      });
    }
  });

  // Endpoint 2: Fetchdynamic class section from AJAX
  app.get('/api/timetable/sections', async (req, res) => {
    const classId = req.query.classId;
    if (!classId) {
      return res.status(400).json({ error: 'Missing classId query parameter' });
    }

    try {
      console.log(`Scraping sections for classId=${classId} from slc.collegett.in...`);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const response = await fetch(`http://slc.collegett.in/admin/class_section_ajax.php?class_id=${classId}`, {
        signal: controller.signal,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Referer': 'http://slc.collegett.in/'
        }
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Ajax section fetch failed: status ${response.status}`);
      }

      const rawOptions = await response.text();
      
      // Parse option elements from Ajax response
      const optionRegex = /<option[^>]*value="([^"]*)"[^>]*>([\s\S]*?)<\/option>/gi;
      const sections: { value: string; text: string }[] = [];
      let optMatch;
      while ((optMatch = optionRegex.exec(rawOptions)) !== null) {
        const val = optMatch[1].trim();
        const text = optMatch[2].replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
        
        if (text && !text.toLowerCase().startsWith('select ')) {
          sections.push({ value: val, text });
        }
      }

      // Add a fallback if empty
      if (sections.length === 0) {
        sections.push({ value: 'None', text: 'None' });
        sections.push({ value: 'A', text: 'Section A' });
        sections.push({ value: 'B', text: 'Section B' });
      }

      res.json({ success: true, sections });
    } catch (err: any) {
      console.warn(`Fetch sections failed for classId=${classId}:`, err.message);
      res.json({
        success: true,
        sections: [
          { value: 'None', text: 'None' },
          { value: 'A', text: 'Section A' },
          { value: 'B', text: 'Section B' }
        ]
      });
    }
  });

  // Endpoint 3: Submit parameters to scrape current official scheduled timetable slots
  app.post('/api/timetable/submit', async (req, res) => {
    const { classId, semester, class_section, teacher, roomno, day, period } = req.body;

    try {
      console.log('Submitting live form query to slc.collegett.in...', req.body);
      
      const params = new URLSearchParams();
      params.append('classId', classId || '');
      params.append('semester', semester || '');
      params.append('class_section', class_section || '');
      params.append('teacher', teacher || '');
      params.append('roomno', roomno || '');
      params.append('day', day || '');
      params.append('period', period || '');
      params.append('submit', 'Go');

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s wait maximum

      const response = await fetch('http://slc.collegett.in/', {
        method: 'POST',
        body: params,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Referer': 'http://slc.collegett.in/'
        }
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`Timetable POST server failed with state ${response.status}`);
      }

      const html = await response.text();
      const parsedResults = parseTimetableTable(html);

      res.json({
        success: true,
        ...parsedResults
      });
    } catch (err: any) {
      console.error('Submit query to SLC failed:', err.message);
      res.status(500).json({
        success: false,
        error: 'Failed to synchronize with Delhi University portal slc.collegett.in. The server is either offline or slow.'
      });
    }
  });

  // ========================================================
  // DEPLOYMENT SERVING FLOWS
  // ========================================================

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[FULLSTACK] Server running on http://localhost:${PORT}`);
  });
}

startServer();
